# 生成笔记插图：在 笔记/ 目录下运行  Rscript scripts/make_figures.R
# 数据取自上一级的 data/；图存到 figures/
suppressPackageStartupMessages({library(MASS); library(emmeans)})
oi <- c(blue = "#0072B2", verm = "#D55E00", green = "#009E73")
ink <- "#1A1A1A"; ink2 <- "#5B5A56"; ctx <- "#9A9893"; grid_c <- "#E6E5E1"
dir.create("figures", showWarnings = FALSE)
base_par <- function(...) par(mar = c(4, 4.2, 2, 1), mgp = c(2.4, 0.7, 0),
                              cex = 0.85, las = 1, tcl = -0.3, ...)

# ---- 图 1：datasetB 的四张诊断图 ----
d <- read.csv("../data/datasetB.csv")
m <- lm(glu ~ age + bmi + waist, data = d)
pdf("figures/fig1_diag4.pdf", width = 7.2, height = 6, useDingbats = FALSE)
palette(c(ink, oi[["verm"]], ink2))
par(mfrow = c(2, 2)); base_par()
plot(m, labels.id = d$id, sub.caption = "", col = ctx, pch = 19, cex = 0.8,
     col.smooth = oi[["blue"]], lwd = 1.6, cex.id = 0.85, cex.caption = 0.95)
dev.off(); palette("default")

# ---- 图 2：岭迹与 GCV ----
lam <- seq(0, 100, 0.5)
rr <- lm.ridge(glu ~ age + bmi + waist, data = d, lambda = lam)
b <- t(rr$coef); lg <- rr$lambda[which.min(rr$GCV)]
pdf("figures/fig2_ridge.pdf", width = 7.2, height = 3.2, useDingbats = FALSE)
par(mfrow = c(1, 2)); base_par()
matplot(lam, b, type = "n", xlab = expression(lambda),
        ylab = "standardized coefficient", main = "(a) Ridge trace",
        font.main = 1, cex.main = 1)
abline(h = 0, col = grid_c, lwd = 1.2)
abline(v = lg, lty = 2, col = ink2)
matlines(lam, b, lty = c(1, 2, 4), lwd = 2, col = oi)
legend("right", c("age", "bmi", "waist"), col = oi, lty = c(1, 2, 4), lwd = 2,
       bty = "n", cex = 0.9)
text(lg, 0.42, bquote(lambda[GCV] == .(lg)), pos = 4, cex = 0.85, col = ink2)
plot(lam, rr$GCV * 1000, type = "l", lwd = 2, col = oi[["blue"]],
     xlab = expression(lambda), ylab = expression(GCV ~ (10^-3)),
     main = "(b) GCV is almost flat", font.main = 1, cex.main = 1)
points(lg, min(rr$GCV) * 1000, pch = 21, bg = "white", col = oi[["blue"]], cex = 1.2)
dev.off()

# ---- 图 3：2x2 析因交互图 ----
f2 <- read.csv("../data/sbp_factorial2x2.csv")
cm <- with(f2, tapply(sbp_drop, list(a, b), mean))
se <- with(f2, tapply(sbp_drop, list(a, b), function(x) sd(x) / sqrt(length(x))))
pdf("figures/fig3_factorial.pdf", width = 3.8, height = 3.2, useDingbats = FALSE)
base_par()
plot(NA, xlim = c(-0.3, 1.3), ylim = c(0, 22), xaxt = "n", xlab = "Drug A",
     ylab = "SBP reduction (mmHg)")
axis(1, at = 0:1, labels = c("not used", "used"))
for (j in 1:2) {
  arrows(0:1, cm[, j] - se[, j], 0:1, cm[, j] + se[, j], angle = 90, code = 3,
         length = 0.03, col = ink2)
  lines(0:1, cm[, j], col = oi[j], lwd = 2.2, lty = j)
  points(0:1, cm[, j], pch = c(21, 24)[j], bg = oi[j], col = ink, cex = 1.1)
}
legend("topleft", c("Drug B not used", "Drug B used"), col = oi[1:2], pt.bg = oi[1:2],
       pch = c(21, 24), lty = 1:2, lwd = 2, bty = "n", cex = 0.85)
dev.off()

# ---- 图 4：协方差分析 ----
g <- read.csv("../data/datasetC_glm.csv")
g$bmi3 <- factor(g$bmi3, levels = c("normal", "overwt", "obese"))
mp <- lm(glu ~ bmi3 + age, data = g)
bp <- read.csv("../data/bp.csv", fileEncoding = "UTF-8")
bp$group <- factor(bp$group, levels = c("方案A", "方案B"), labels = c("A", "B"))
fb <- lm(post ~ base + group, data = bp)
pdf("figures/fig4_ancova.pdf", width = 7.2, height = 3.3, useDingbats = FALSE)
par(mfrow = c(1, 2)); base_par()
plot(glu ~ age, data = g, type = "n", xlab = "Age (years)",
     ylab = "Fasting glucose (mmol/L)", main = "(a) Common slope, three intercepts",
     font.main = 1, cex.main = 1)
abline(v = mean(g$age), lty = 2, col = ctx)
pchs <- c(21, 24, 22)
for (i in 1:3) {
  s <- g[g$bmi3 == levels(g$bmi3)[i], ]
  points(s$age, s$glu, pch = pchs[i], col = oi[i], bg = adjustcolor(oi[i], 0.35),
         cex = 0.7)
  xs <- range(g$age)
  lines(xs, predict(mp, data.frame(age = xs, bmi3 = levels(g$bmi3)[i])),
        col = oi[i], lwd = 2.2)
}
legend("topleft", levels(g$bmi3), col = oi, pt.bg = adjustcolor(oi, 0.35), pch = pchs,
       lwd = 2, bty = "n", cex = 0.85)
raw <- t(sapply(split(bp$post, bp$group), function(x) {
  h <- qt(0.975, length(x) - 1) * sd(x) / sqrt(length(x)); mean(x) + c(0, -1, 1) * h }))
adj <- as.matrix(summary(emmeans(fb, ~ group))[, c("emmean", "lower.CL", "upper.CL")])
plot(NA, xlim = c(0.5, 2.5), ylim = c(124, 142), xaxt = "n", xlab = "Regimen",
     ylab = "SBP at week 8 (mmHg)", main = "(b) bp.csv: crude vs adjusted",
     font.main = 1, cex.main = 1)
axis(1, at = 1:2, labels = c("A", "B"))
xl <- 1:2 - 0.12; xr <- 1:2 + 0.12
arrows(xl, raw[, 2], xl, raw[, 3], angle = 90, code = 3, length = 0.03, col = ctx)
points(xl, raw[, 1], pch = 21, bg = "white", col = ink2, cex = 1.2)
arrows(xr, adj[, 2], xr, adj[, 3], angle = 90, code = 3, length = 0.03, col = oi[1:2])
points(xr, adj[, 1], pch = 21, bg = oi[1:2], col = ink, cex = 1.2)
legend("topleft", c("crude mean", sprintf("adjusted to base = %.1f", mean(bp$base))),
       pch = 21, pt.bg = c("white", ink2), col = c(ink2, ink), bty = "n", cex = 0.85)
dev.off()

# ---- 图 5：重复测量轨迹 ----
dm <- read.csv("../data/dm.csv", fileEncoding = "UTF-8")
Y <- as.matrix(dm[, c("hba1c_0", "hba1c_3", "hba1c_6")])
gi <- as.integer(factor(dm$group)); tt <- c(0, 3, 6)
mm <- sapply(1:3, function(j) tapply(Y[, j], gi, mean))
ci <- sapply(1:3, function(j) tapply(Y[, j], gi, function(x)
  qt(0.975, length(x) - 1) * sd(x) / sqrt(length(x))))
pdf("figures/fig5_rm.pdf", width = 7.2, height = 3.2, useDingbats = FALSE)
par(mfrow = c(1, 2)); base_par()
plot(NA, xlim = c(-0.6, 6.6), ylim = c(6.2, 9.2), xaxt = "n", xlab = "Month",
     ylab = "HbA1c (%)", main = "(a) Group means, 95% CI", font.main = 1, cex.main = 1)
axis(1, at = tt)
for (i in 1:2) {
  x <- tt + c(-0.12, 0.12)[i]
  arrows(x, mm[i, ] - ci[i, ], x, mm[i, ] + ci[i, ], angle = 90, code = 3,
         length = 0.03, col = oi[i])
  lines(x, mm[i, ], col = oi[i], lwd = 2.2, lty = i)
  points(x, mm[i, ], pch = c(21, 24)[i], bg = oi[i], col = ink, cex = 1.1)
}
legend("topright", c("Drug A", "Drug B"), col = oi[1:2], pt.bg = oi[1:2],
       pch = c(21, 24), lty = 1:2, lwd = 2, bty = "n", cex = 0.85)
plot(NA, xlim = c(-0.3, 6.3), ylim = range(Y), xaxt = "n", xlab = "Month",
     ylab = "HbA1c (%)", main = "(b) Individual trajectories", font.main = 1,
     cex.main = 1)
axis(1, at = tt)
for (j in seq_len(nrow(Y))) lines(tt, Y[j, ], col = adjustcolor(oi[gi[j]], 0.35))
for (i in 1:2) lines(tt, mm[i, ], col = oi[i], lwd = 2.6, lty = i)
dev.off()
cat("figures done\n")
