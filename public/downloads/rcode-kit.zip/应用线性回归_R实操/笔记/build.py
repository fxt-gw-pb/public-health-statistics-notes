#!/usr/bin/env python3
"""Build the notes template with checked syntax highlighting and XeLaTeX.

    python build.py                  # the only root entry .tex -> <name>.pdf
    python build.py 统计推断_1013     # 统计推断_1013.tex -> 统计推断_1013.pdf
    python build.py --keep-build     # also keep build/ (aux, logs) after success
    python build.py --highlight-only # prepare/check highlighting only

Intermediate files go to build/. After a successful build the PDF is placed
next to its .tex in the project root and build/ is deleted, so only source
and PDF remain. A failed build keeps build/ for its logs.

Pygments is optional when the bundled source/configuration/output hashes match.
Install Pygments to update highlighted code. XeLaTeX always uses
-no-shell-escape; source-code files are formatted, not executed.

Slide projects carry no scripts/highlight.py; highlighting is then skipped and
only the XeLaTeX passes run.
"""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path
import re
import shutil
import subprocess
import sys

# Keep the project free of __pycache__ from loading the bundled helper.
sys.dont_write_bytecode = True

PROJECT_ROOT = Path(__file__).resolve().parent

# Load our own helper by its absolute path, including with PYTHONSAFEPATH=1
# or when this script is launched from a different working directory.
_HIGHLIGHT_SCRIPT = PROJECT_ROOT / "scripts" / "highlight.py"
if _HIGHLIGHT_SCRIPT.is_file():
    _highlighter_spec = importlib.util.spec_from_file_location(
        "pku_template_highlight", _HIGHLIGHT_SCRIPT
    )
    if _highlighter_spec is None or _highlighter_spec.loader is None:
        raise RuntimeError("The bundled scripts/highlight.py could not be loaded.")
    _highlighter = importlib.util.module_from_spec(_highlighter_spec)
    sys.modules[_highlighter_spec.name] = _highlighter
    _highlighter_spec.loader.exec_module(_highlighter)
    HighlightError = _highlighter.HighlightError
    ensure_cache = _highlighter.ensure_cache
else:
    # Slide projects have no code highlighter.
    class HighlightError(Exception):
        """A build error reported to the user."""

    ensure_cache = None


# Root .tex files that are inputs or reference starters, never entry points.
NON_ENTRY_TEX = {
    "settings.tex", "pku-font-latin.tex", "pku-font-math.tex", "pku-font-cjk.tex",
    "starter.tex", "notes-starter.tex", "progress-starter.tex", "slides-starter.tex",
}
# Compiler by-products that a direct xelatex run may leave in the root.
AUX_SUFFIXES = (
    ".aux", ".log", ".toc", ".out", ".xdv", ".synctex.gz", ".fls",
    ".fdb_latexmk", ".bbl", ".blg", ".bcf", ".run.xml", ".lof", ".lot",
    ".listing", ".nav", ".snm", ".vrb",
)


def _target_name(value: str) -> str:
    name = value[:-4] if value.endswith(".tex") else value
    # Unicode (e.g. Chinese) names are fine; reject paths, whitespace and
    # characters that TeX or the shell would interpret.
    if not re.fullmatch(r"[^\s/\\{}$&#^~%\"'*?<>|:.-][^\s/\\{}$&#^~%\"'*?<>|:]*", name):
        raise argparse.ArgumentTypeError(
            "Use a project-root document name such as 统计推断_1013 or report.tex. "
            "Paths, whitespace, TeX special characters and names beginning "
            "with '-' or '.' are not accepted."
        )
    return name


def _detect_target() -> str:
    candidates = []
    for path in sorted(PROJECT_ROOT.glob("*.tex")):
        if path.name in NON_ENTRY_TEX:
            continue
        try:
            head = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if re.search(r"^[^%\n]*\\documentclass", head, re.MULTILINE):
            candidates.append(path.stem)
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise HighlightError("No entry .tex file with \\documentclass was found in the project root.")
    raise HighlightError(
        "Several entry .tex files were found; name one explicitly: " + ", ".join(candidates)
    )


def _remove_root_aux(target: str) -> None:
    for suffix in AUX_SUFFIXES:
        stray = PROJECT_ROOT / f"{target}{suffix}"
        if stray.is_file():
            stray.unlink()


def _log_tail(path: Path, lines: int = 30) -> str:
    try:
        return "\n".join(
            path.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:]
        )
    except OSError:
        return "(The compiler log could not be read.)"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "target", nargs="?", default=None,
        type=_target_name,
        help="project-root .tex document (default: the only entry .tex in the root)",
    )
    parser.add_argument(
        "--keep-build", action="store_true",
        help="keep build/ with aux files and logs after a successful build",
    )
    parser.add_argument(
        "--highlight-only", action="store_true",
        help="prepare or verify syntax highlighting, then stop",
    )
    arguments = parser.parse_args(argv)

    try:
        if ensure_cache is not None:
            result = ensure_cache(PROJECT_ROOT)
            verb = "Regenerated" if result["mode"] == "generated" else "Verified cached"
            print(f"{verb} highlighting for {result['source_count']} source file(s).", flush=True)
        elif arguments.highlight_only:
            print("This project has no scripts/highlight.py; nothing to highlight.")
        if arguments.highlight_only:
            return 0

        target = arguments.target or _detect_target()
        source = PROJECT_ROOT / f"{target}.tex"
        if not source.is_file():
            raise HighlightError(f"Document not found: {source}")
        engine = shutil.which("xelatex")
        if engine is None:
            raise HighlightError(
                "XeLaTeX was not found. Install TeX Live or MiKTeX with XeLaTeX, "
                "Einfart, CTeX and the template's other LaTeX dependencies, "
                "then make xelatex available on PATH."
            )

        output_dir = PROJECT_ROOT / "build"
        output_dir.mkdir(parents=True, exist_ok=True)
        command = [
            engine,
            "-no-shell-escape",
            "-interaction=nonstopmode",
            "-halt-on-error",
            "-file-line-error",
            "-output-directory=build",
            source.name,
        ]
        for pass_number in range(1, 4):
            console_log = output_dir / f"{target}-pass{pass_number}.log"
            print(f"XeLaTeX pass {pass_number}/3: {source.name}", flush=True)
            with console_log.open("w", encoding="utf-8", newline="\n") as stream:
                completed = subprocess.run(
                    command,
                    cwd=PROJECT_ROOT,
                    stdout=stream,
                    stderr=subprocess.STDOUT,
                    shell=False,
                    check=False,
                )
            if completed.returncode:
                raise HighlightError(
                    f"XeLaTeX failed on pass {pass_number}. "
                    "No successful new PDF is being reported.\n"
                    f"Log: {console_log}\n\n{_log_tail(console_log)}"
                )

        built = output_dir / f"{target}.pdf"
        if not built.is_file() or built.stat().st_size == 0:
            raise HighlightError(f"XeLaTeX did not produce a nonempty PDF: {built}")
        pdf = PROJECT_ROOT / f"{target}.pdf"
        shutil.copy2(built, pdf)
        _remove_root_aux(target)
        if arguments.keep_build:
            print(f"LaTeX log: {output_dir / (target + '.log')}")
        else:
            shutil.rmtree(output_dir)
            print("Removed intermediate files (build/).")
        print(f"Built: {pdf}")
    except (HighlightError, OSError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nBuild interrupted.", file=sys.stderr)
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
