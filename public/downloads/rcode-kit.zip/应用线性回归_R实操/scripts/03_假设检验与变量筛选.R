# ============================================================
# 03  嵌套模型的 F 检验、I/II/III 型平方和、变量筛选
# 对应：第一讲后半（变量筛选）、第二讲旧版第零关；
#       课堂代码 筛选自变量.R、stepwise.R、回归诊断.R 前半
# 数据：datasetC.csv（课件里叫 datasetC_sel.csv，n = 200，5 个候选自变量）
#       diabetes27_hw.csv（27 例糖尿病，作业一、二）
# 对应笔记：第 3 章
# ============================================================

library(car)      # Anova()
library(leaps)    # regsubsets()
library(olsrr)    # ols_step_*_p()

dc <- read.csv("data/datasetC.csv")[, -1]     # 去掉 id
dd <- read.csv("data/diabetes27_hw.csv")[, -1]
str(dc); str(dd)


# 3.1 嵌套模型的增量 F 检验：anova(小模型, 大模型) ---------------------------------

full <- lm(glucose ~ tc + tg + insulin + hba1c, data = dd)
m3   <- lm(glucose ~ tg + insulin + hba1c, data = dd)
anova(m3, full)                       # 检验 tc：F = 0.153，P = 0.700

# 手算偏 F：(SSE小 - SSE大) / Δdf ÷ MSE大
F_tc <- (deviance(m3) - deviance(full)) / 1 / (deviance(full) / df.residual(full))
c(F = F_tc, P = pf(F_tc, 1, df.residual(full), lower.tail = FALSE))

# 单个变量：偏 F = t²
coef(summary(full))[, "t value"]^2

# 一次检验多个变量（H0：tc、tg 的系数同时为 0）
anova(lm(glucose ~ insulin + hba1c, data = dd), full)


# 3.2 drop1() / add1()：每个变量各做一次偏 F ----------------------------------------

drop1(full, test = "F")               # 逐个删一个变量：后退法每一步看的就是它
add1(lm(glucose ~ 1, data = dd), scope = ~ tc + tg + insulin + hba1c,
     test = "F")                      # 逐个加一个变量：前进法每一步看的就是它


# 3.3 I 型、II 型、III 型平方和 ------------------------------------------------------

anova(lm(glucose ~ tc + tg, data = dd))     # I 型：顺序平方和，先进先得
anova(lm(glucose ~ tg + tc, data = dd))     # 顺序一换，结果就变
cor(dd$tc, dd$tg)                           # 因为 tc、tg 相关（r = 0.63）

Anova(lm(glucose ~ tc + tg, data = dd), type = "II")   # 与顺序无关
Anova(full, type = "II")                    # 无交互时 II 型 = drop1 的偏 F
# III 型用于含交互的模型，因子要先设和为零编码，见脚本 06


# 3.4 为什么不能用 R² 选模型 --------------------------------------------------------------

forms <- list(
  "1"                          = glu ~ 1,
  "age"                        = glu ~ age,
  "age+bmi"                    = glu ~ age + bmi,
  "age+bmi+exercise"           = glu ~ age + bmi + exercise,
  "age+bmi+exercise+sleep"     = glu ~ age + bmi + exercise + sleep,
  "full"                       = glu ~ age + bmi + exercise + sleep + waist)
fits <- lapply(forms, lm, data = dc)
round(t(sapply(fits, function(m) c(
  p     = length(coef(m)) - 1,
  R2    = summary(m)$r.squared,
  adjR2 = summary(m)$adj.r.squared,
  AIC   = AIC(m),
  BIC   = BIC(m)))), 4)
# R² 一路上升；调整 R²、AIC、BIC 都在 age+bmi+exercise 处最优


# 3.5 全子集：leaps::regsubsets() ------------------------------------------------------

all_sub <- regsubsets(glu ~ ., data = dc, nbest = 1)   # 每个变量个数下留最好的 1 个
ss <- summary(all_sub)
ss$which                                   # 每行是哪几个变量
round(cbind(adjR2 = ss$adjr2, Cp = ss$cp, BIC = ss$bic), 3)
which.max(ss$adjr2); which.min(ss$cp); which.min(ss$bic)
coef(all_sub, 3)                           # 第 3 行模型的系数
plot(all_sub, scale = "adjr2")             # 黑格 = 入选

# nbest = 5：每个变量个数下列出前 5 个，看看"次优"的有多接近
summary(regsubsets(glucose ~ ., data = dd, nbest = 5))$adjr2


# 3.6 按 AIC 的逐步法：step() ---------------------------------------------------------------

m0  <- lm(glu ~ 1, data = dc)
mfull <- lm(glu ~ age + bmi + waist + sleep + exercise, data = dc)

step(mfull, direction = "backward")                         # 后退
step(m0, scope = list(lower = ~ 1, upper = formula(mfull)),
     direction = "forward")                                 # 前进
step(m0, scope = list(lower = ~ 1, upper = formula(mfull)),
     direction = "both")                                    # 逐步（双向）
step(m0, scope = list(lower = ~ 1, upper = formula(mfull)),
     direction = "both", k = log(nrow(dc)))                 # 按 BIC

# 必须保留的混杂因素：放进 lower，step() 就不会删它
step(mfull, scope = list(lower = ~ age, upper = formula(mfull)),
     direction = "both", trace = 0)

# step() 打印的 AIC 是 extractAIC()：n·ln(SSE/n) + 2(p+1)
# 换成 AIC() 的数值：加上 n(1 + ln 2π) + 2（课堂代码"-140.97 + ..."那几行）
n <- nrow(dc)
extractAIC(m0)[2] + n * (1 + log(2 * pi)) + 2
AIC(m0)


# 3.7 按 P 值的前进 / 后退 / 逐步：手工一步步走 --------------------------------------------

sc <- ~ tc + tg + insulin + hba1c
s0 <- lm(glucose ~ 1, data = dd)
add1(s0, sc, test = "F")                             # 第 1 步：hba1c 进入
s1 <- update(s0, . ~ . + hba1c)
add1(s1, sc, test = "F")                             # 第 2 步：tc 进入（P = 0.03）
s2 <- update(s1, . ~ . + tc)
drop1(s2, test = "F")                                # 逐步法：进完要回头看能否删
add1(s2, sc, test = "F")                             # 第 3 步：最小 P = 0.088

# 后退法：从全模型删
drop1(full, test = "F")                              # tc 的 P 最大（0.70），删
drop1(update(full, . ~ . - tc), test = "F")          # 其余都 < 0.05，停

# 把后退法写成函数（作业一 bootstrap 用到）
backward_p <- function(dat, vars, y, alpha = 0.05) {
  repeat {
    if (length(vars) == 0) break
    m <- lm(reformulate(vars, y), data = dat)
    pv <- drop1(m, test = "F")[-1, "Pr(>F)"]
    if (max(pv) < alpha) break
    vars <- vars[-which.max(pv)]
  }
  vars
}
backward_p(dd, c("tc", "tg", "insulin", "hba1c"), "glucose")


# 3.8 olsrr：按 P 值的自动逐步（课堂代码用的包） -------------------------------------------

# 参数名：前进、后退用 p_val；逐步用 p_enter、p_remove（写错名字不会报错，只会被忽略）
ols_step_forward_p(full, p_val = 0.05)
ols_step_backward_p(full, p_val = 0.05)
k <- ols_step_both_p(full, p_enter = 0.10, p_remove = 0.15)
k
k$model                               # 最终模型（lm 对象）


# 3.9 筛选结果稳不稳：bootstrap 重抽样 --------------------------------------------------------

set.seed(2026)
sel <- replicate(500, {
  i <- sample(nrow(dd), replace = TRUE)
  paste(backward_p(dd[i, ], c("tc", "tg", "insulin", "hba1c"), "glucose"),
        collapse = "+")
})
head(sort(table(sel), decreasing = TRUE) / 500)     # 最常选中的模型只占约 3 成
sapply(c("tc", "tg", "insulin", "hba1c"), function(v) mean(grepl(v, sel)))
