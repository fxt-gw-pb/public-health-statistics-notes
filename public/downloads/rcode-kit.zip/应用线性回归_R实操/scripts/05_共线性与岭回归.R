# ============================================================
# 05  共线性诊断与岭回归
# 对应：第二讲《回归诊断》第二关；课堂代码 回归诊断.R 末尾（vif、kappa、特征值）
# 数据：datasetB.csv（bmi 与 waist 的相关系数 0.968）
# 对应笔记：第 5 章
# ============================================================

library(car)    # vif
library(MASS)   # lm.ridge

d <- read.csv("data/datasetB.csv")
x <- c("age", "bmi", "waist")
m <- lm(glu ~ age + bmi + waist, data = d)


# 5.1 先看自变量之间的相关 ------------------------------------------------------------

round(cor(d[, c(x, "glu")]), 3)          # r(bmi, waist) = 0.968
pairs(d[, x], pch = 19, cex = 0.5, col = "grey40")


# 5.2 共线性的后果：五个模型并排 ------------------------------------------------------------

mods <- list(
  "bmi"             = lm(glu ~ bmi, data = d),
  "waist"           = lm(glu ~ waist, data = d),
  "age+bmi"         = lm(glu ~ age + bmi, data = d),
  "age+waist"       = lm(glu ~ age + waist, data = d),
  "age+bmi+waist"   = m)
get <- function(fit, v) {
  out <- if (v %in% names(coef(fit))) coef(summary(fit))[v, c(1, 2, 4)] else rep(NA, 3)
  setNames(out, c("b", "SE", "P"))
}
round(t(sapply(mods, function(f) c(bmi = get(f, "bmi"), waist = get(f, "waist")))), 4)
# 单独放都显著；一起放都不显著，waist 还变成负号


# 5.3 VIF 与容忍度 ---------------------------------------------------------------------------

vif(m)                                   # 1.03、16.02、16.14
1 / vif(m)                               # 容忍度 TOL

# 手算：某个 x 对其余 x 回归的 R²，VIF = 1/(1 - R²)
r2_bmi <- summary(lm(bmi ~ age + waist, data = d))$r.squared
1 / (1 - r2_bmi)

# 一行算全部
sapply(x, function(v) 1 / (1 - summary(lm(reformulate(setdiff(x, v), v),
                                          data = d))$r.squared))

# √VIF = 标准误膨胀倍数：bmi 的标准误从 0.0138（不含 waist）到 0.0552
se_alone <- coef(summary(lm(glu ~ age + bmi, data = d)))["bmi", 2]
se_full  <- coef(summary(m))["bmi", 2]
c(ratio = se_full / se_alone, sqrtVIF = sqrt(vif(m)["bmi"]))


# 5.4 特征值与条件数 -------------------------------------------------------------------------

ev <- eigen(cor(d[, x]))$values
ev                                        # 最小特征值接近 0 = 某个方向几乎没有信息
sqrt(max(ev) / min(ev))                   # 条件数 κ = 7.9
sqrt(ev[1] / ev)                          # 各维的条件指数
kappa(scale(d[, x]), exact = TRUE)        # 同一个 κ：标准化 X 的最大/最小奇异值之比
# 课堂代码写的是 kappa(scale(d))：默认 exact = FALSE 只给近似值，
# 而且把 glu 也放进去了。诊断共线性只放自变量，并加 exact = TRUE


# 5.5 岭回归：MASS::lm.ridge() ---------------------------------------------------------------

lam <- seq(0, 100, by = 0.5)
rr <- lm.ridge(glu ~ age + bmi + waist, data = d, lambda = lam)

select(rr)                                # HKB、L-W 估计与 GCV 最小的 λ（7.5）
rr$lambda[which.min(rr$GCV)]

# 两套系数，容易搞混：
#   rr$coef   自变量已标准化（按 n 作分母的 SD），没有截距；画岭迹用它
#   coef(rr)  还原到原始单位，带截距；写回归方程用它
dim(rr$coef)                              # 3 × 201：行 = 变量，列 = λ
round(t(rr$coef)[lam %in% c(0, 7.5, 20, 30, 60), ], 3)
round(coef(rr)[lam %in% c(0, 7.5, 30), ], 4)

# λ = 0 时就是 OLS
rbind(ridge0 = coef(rr)[1, ], ols = coef(m))


# 5.6 岭迹图 -------------------------------------------------------------------------------

matplot(rr$lambda, t(rr$coef), type = "l", lty = 1, lwd = 2,
        col = c("#0072B2", "#D55E00", "#009E73"),
        xlab = expression(lambda), ylab = "standardized coefficient")
abline(h = 0, col = "grey70")
abline(v = rr$lambda[which.min(rr$GCV)], lty = 2, col = "grey40")
legend("topright", x, col = c("#0072B2", "#D55E00", "#009E73"), lty = 1, lwd = 2,
       bty = "n")

plot(rr$lambda, rr$GCV, type = "l", xlab = expression(lambda), ylab = "GCV")
# GCV 曲线在 0–20 之间几乎是平的：共线性不伤预测，所以 GCV 帮不上"读系数"的忙


# 5.7 自己写岭回归：(Z'Z + λI)^-1 Z'y -----------------------------------------------------

lambda <- 30
X  <- as.matrix(d[, x])
Xc <- scale(X, center = TRUE, scale = FALSE)
sc <- sqrt(colSums(Xc^2) / nrow(X))          # lm.ridge 用 n 作分母
Z  <- sweep(Xc, 2, sc, "/")
yc <- d$glu - mean(d$glu)
b_std <- solve(crossprod(Z) + lambda * diag(3), crossprod(Z, yc))
b_raw <- drop(b_std) / sc
b0    <- mean(d$glu) - sum(b_raw * colMeans(X))
rbind(hand = c(b0, b_raw),
      MASS = coef(lm.ridge(glu ~ age + bmi + waist, data = d, lambda = lambda)))

# 相关阵形式：b(k) = (R + kI)^-1 r_y，k 与 λ 的换算 k = λ/n（按 n 标准化时）
R  <- cor(X); ry <- cor(X, d$glu)
k  <- lambda / nrow(X)
drop(solve(R + k * diag(3), ry))             # 标准化岭回归系数（y 也标准化）
drop(b_std) / (sd(d$glu) * sqrt((nrow(X) - 1) / nrow(X)))   # 同一组数，再除以 y 的 SD


# 5.8 比岭回归更常用的处理：只留一个，或合成一个 --------------------------------------------

summary(lm(glu ~ age + bmi, data = d))$coefficients          # 只留 BMI
d$obesity <- (as.numeric(scale(d$bmi)) + as.numeric(scale(d$waist))) / 2
summary(lm(glu ~ age + obesity, data = d))$coefficients      # z 分数平均
pc <- prcomp(d[, c("bmi", "waist")], scale. = TRUE)
summary(pc)                                                  # 第一主成分占 98%
d$pc1 <- pc$x[, 1]
coef(summary(lm(glu ~ age + pc1, data = d)))   # 主成分的正负号是任意的，这里 pc1 越小越胖


# 5.9 强影响点会左右岭参数的选择（作业二的核心） --------------------------------------------

sets <- list(all = 1:150, del149 = setdiff(1:150, 149))
for (s in names(sets)) {
  r <- lm.ridge(glu ~ age + bmi + waist, data = d[sets[[s]], ], lambda = lam)
  b <- t(r$coef)
  first_pos <- lam[which(b[, "waist"] > 0 & b[, "bmi"] > 0)[1]]
  cat(s, ": GCV 最优 λ =", r$lambda[which.min(r$GCV)],
      "；bmi、waist 同时为正的最小 λ =", first_pos, "\n")
}
