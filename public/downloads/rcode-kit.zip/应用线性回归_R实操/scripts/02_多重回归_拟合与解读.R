# ============================================================
# 02  多重线性回归：拟合、读输出、区间、标准化系数、相关、矩阵解
# 对应：第一讲《模型、估计与解释》；课堂代码 R上手_课件一.R、回归2.R
# 数据：datasetA.csv（n = 200，模拟体检数据：age 岁、bmi kg/m²、glu mmol/L）
# 对应笔记：第 2 章
# ============================================================

d <- read.csv("data/datasetA.csv")
str(d)
summary(d)


# 2.1 先画图、看相关 -------------------------------------------------------------

round(cor(d[, c("age", "bmi", "glu")]), 4)
# r(glu, bmi) = 0.5055，r(glu, age) = 0.5549，r(bmi, age) = 0.3205
pairs(d[, c("age", "bmi", "glu")], pch = 19, col = "grey40", cex = 0.6)
plot(glu ~ bmi, data = d, xlab = "BMI", ylab = "glucose (mmol/L)")


# 2.2 粗效应与调整效应 -------------------------------------------------------------

fit1 <- lm(glu ~ bmi, data = d)          # 简单回归
fit2 <- lm(glu ~ age + bmi, data = d)    # 多重回归

summary(fit1)
summary(fit2)

coef(fit1)["bmi"]                        # 0.1063
coef(fit2)["bmi"]                        # 0.0768
coef(fit1)["bmi"] / coef(fit2)["bmi"] - 1   # 粗效应比调整效应高 38%

# 两个模型的 bmi 一行并排
rbind(crude    = coef(summary(fit1))["bmi", ],
      adjusted = coef(summary(fit2))["bmi", ])


# 2.3 分层：偏回归系数的直观来源 ---------------------------------------------------

d$agegrp <- cut(d$age, breaks = c(29, 45, 58, 79),
                labels = c("30-45", "46-58", "59-78"))
table(d$agegrp)                                       # 56 / 94 / 50
sapply(split(d, d$agegrp), function(s) coef(lm(glu ~ bmi, data = s))["bmi"])
# 三层斜率 0.101 / 0.071 / 0.101

# 三条线是否平行：比较"共斜率模型"与"各层不同斜率模型"
m_common <- lm(glu ~ bmi + agegrp, data = d)
m_sep    <- lm(glu ~ bmi * agegrp, data = d)
anova(m_common, m_sep)                                # F = 0.70，P = 0.50
coef(m_common)["bmi"]                                 # 共斜率 0.086


# 2.4 summary() 的 7 个数：逐个取出来 --------------------------------------------

s <- summary(fit2)
s$coefficients                 # Estimate、Std. Error、t value、Pr(>|t|)
s$sigma                        # 剩余标准差 0.5393
s$df                           # (p+1, n-p-1, p+1)：3、197、3
s$r.squared                    # 0.4276
s$adj.r.squared                # 0.4218
s$fstatistic                   # F = 73.58，df = 2、197
pf(s$fstatistic[1], s$fstatistic[2], s$fstatistic[3], lower.tail = FALSE)

# 手算核对：t = b / SE，P = 2 * pt(-|t|, df)
b  <- coef(fit2); se <- sqrt(diag(vcov(fit2)))
cbind(t = b / se, P = 2 * pt(-abs(b / se), df.residual(fit2)))

# 校正 R²：1 - (1 - R²)(n - 1)/(n - p - 1)
n <- nrow(d); p <- 2
1 - (1 - s$r.squared) * (n - 1) / (n - p - 1)


# 2.5 方差分析表：平方和怎么拆 ------------------------------------------------------

anova(fit2)                    # 顺序（I 型）平方和：age 先进，bmi 是"调整 age 后"的增量
anova(lm(glu ~ bmi + age, data = d))   # 顺序换了，两行 SS 都变；残差行不变
sum(anova(fit2)$`Sum Sq`)      # = 总平方和 100.089
sum((d$glu - mean(d$glu))^2)

# MSE 用 n - p - 1 作分母
sse <- deviance(fit2); sse / df.residual(fit2); sigma(fit2)^2


# 2.6 系数的 95% 置信区间 -----------------------------------------------------------

confint(fit2)
confint(fit2, level = 0.99)
# 手算：b ± t(0.975, 197) × SE
tq <- qt(0.975, df.residual(fit2))
cbind(lower = b - tq * se, upper = b + tq * se)


# 2.7 预测：均数的 CI 与个体的 PI -----------------------------------------------------

new <- data.frame(age = 52, bmi = 24)            # 列名必须和模型里一模一样
predict(fit2, newdata = new, interval = "confidence")   # 4.98 — 5.13
predict(fit2, newdata = new, interval = "prediction")   # 3.99 — 6.12

# 手算：CI 用 se.fit；PI 用 sqrt(s² + se.fit²)
pr <- predict(fit2, newdata = new, se.fit = TRUE)
c(yhat = pr$fit, se_mean = pr$se.fit,
  se_indiv = sqrt(sigma(fit2)^2 + pr$se.fit^2))

# 一次预测多个点
new3 <- data.frame(age = c(40, 52, 65), bmi = c(22, 24, 28))
cbind(new3, predict(fit2, newdata = new3, interval = "confidence"))


# 2.8 标准化偏回归系数：三种写法结果一致 -----------------------------------------------

# 写法一：b* = b × SD(x) / SD(y)
b[-1] * sapply(d[, c("age", "bmi")], sd) / sd(d$glu)      # age 0.438，bmi 0.365

# 写法二：y 和 x 都标准化后再回归
dz <- as.data.frame(scale(d[, c("age", "bmi", "glu")]))
coef(lm(glu ~ age + bmi, data = dz))

# 易错：只标准化 x、不标准化 y，得到的是"半标准化"系数（差一个 SD(y) 倍）
coef(lm(glu ~ scale(age) + scale(bmi), data = d))[-1]


# 2.9 三种相关：r、复相关 R、偏相关 -----------------------------------------------------

cor(d$glu, d$bmi)                           # 简单相关 0.5055
cor(d$glu, fitted(fit2))                    # 复相关 R = 0.6539
sqrt(summary(fit2)$r.squared)               # 同上

# 偏相关：两组残差的相关（扣掉 age 的线性影响）
e_y <- resid(lm(glu ~ age, data = d))
e_x <- resid(lm(bmi ~ age, data = d))
cor(e_y, e_x)                               # 0.4158

library(ppcor)                              # 课堂用的包
pcor.test(d$glu, d$bmi, d$age)              # estimate 0.4158，statistic 6.416
pcor(d[, c("age", "bmi", "glu")])$estimate  # 偏相关矩阵

# 偏相关的 t 检验 = 偏回归系数的 t 检验
r  <- cor(e_y, e_x); dfp <- n - 2 - 1
r * sqrt(dfp / (1 - r^2))                   # 6.416
coef(summary(fit2))["bmi", "t value"]       # 6.416


# 2.10 矩阵解：lm() 背后在算什么 ---------------------------------------------------------

X <- model.matrix(fit2)                     # 200 × 3，第一列全是 1
y <- d$glu
XtX_inv <- solve(t(X) %*% X)
bhat <- XtX_inv %*% t(X) %*% y              # b = (X'X)^-1 X'y
cbind(bhat, coef(fit2))

H <- X %*% XtX_inv %*% t(X)                 # 帽子矩阵：yhat = H y
all.equal(unname(drop(H %*% y)), unname(fitted(fit2)))
h <- diag(H)                                # 杠杆值
all.equal(unname(h), unname(hatvalues(fit2)))
mean(h); (p + 1) / n                        # 平均杠杆值 = (p+1)/n
which.max(h)                                # 51 号是 x 方向最远的点

e <- y - X %*% bhat
s2 <- sum(e^2) / (n - p - 1)
s2 * XtX_inv                                # 系数协方差阵 = s²(X'X)^-1
vcov(fit2)


# 2.11 似然、AIC、BIC：R 函数与手算 ---------------------------------------------------------

sse <- sum(resid(fit2)^2)
loglik <- -n / 2 * log(2 * pi) - n / 2 * log(sse / n) - n / 2
c(hand = loglik, R = as.numeric(logLik(fit2)))

K <- p + 2                                  # 参数个数：截距 + 2 个系数 + σ²
c(hand = -2 * loglik + 2 * K, R = AIC(fit2))
c(hand = -2 * loglik + log(n) * K, R = BIC(fit2))

# step() 用的是简略 AIC：n·ln(SSE/n) + 2(p+1)，与 AIC() 只差常数
extractAIC(fit2)
n * log(sse / n) + 2 * (p + 1)
AIC(fit2) - extractAIC(fit2)[2]             # = n(1 + ln 2π) + 2，对同一数据是常数


# 2.12 把结果整理成论文表格 -------------------------------------------------------------------

tab <- data.frame(
  term = names(coef(fit2))[-1],
  b    = coef(fit2)[-1],
  lo   = confint(fit2)[-1, 1],
  hi   = confint(fit2)[-1, 2],
  P    = coef(summary(fit2))[-1, 4]
)
tab$report <- sprintf("%.3f (%.3f, %.3f)", tab$b, tab$lo, tab$hi)
tab$P <- format.pval(tab$P, digits = 3, eps = 0.001)
tab[, c("term", "report", "P")]
cat(sprintf("R² = %.3f，s = %.3f，n = %d\n",
            summary(fit2)$r.squared, sigma(fit2), nobs(fit2)))
# 正文写法：在同时调整年龄后，BMI 每增加 1 kg/m²，空腹血糖平均升高 0.077 mmol/L
# （95% CI 0.053–0.100，P < 0.001）。
