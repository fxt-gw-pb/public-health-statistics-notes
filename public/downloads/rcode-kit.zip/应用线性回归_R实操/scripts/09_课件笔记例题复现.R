# ============================================================
# 09  《应用线性回归_课件笔记.pdf》里全部 R 代码块的可运行版本
# 笔记里的数据原先直接写在代码中，现已存为 data/ 下的 CSV（见 data/数据说明.md）
# 按笔记章节顺序排列；每节注释里写了笔记中给出的参考数值，可逐一核对
# 对应本笔记：附录 B
# ============================================================

library(MASS)
library(leaps)
library(lmtest)
library(sandwich)
library(ez)


# 第1章 矩阵知识：均数向量、协方差阵、相关阵 -------------------------------------------

b12 <- read.csv("data/body12.csv")
X <- as.matrix(b12)
colMeans(X)                       # 均数向量
cov(X)                            # 协方差阵
crossprod(scale(X, scale = FALSE))  # 离均差平方和与积和矩阵 = (n - 1) × cov
cor(X)                            # 相关阵
eigen(cor(X))                     # 特征值与特征向量
det(cor(X)); solve(cor(X))        # 行列式与逆矩阵


# 第2章 例3.1：29 名儿童肺活量 v ~ 身高 h + 体重 w ----------------------------------------

lung <- read.csv("data/lung29.csv")
X <- cbind(1, lung$h, lung$w); Y <- lung$v
b <- solve(t(X) %*% X) %*% t(X) %*% Y           # -0.5657、0.005017、0.05406
cbind(b, coef(lm(v ~ h + w, data = lung)))
solve(t(X) %*% X)                               # 笔记给出的 (X'X)^-1

fit <- lm(v ~ h + w, data = lung)
Q <- deviance(fit); n <- 29; p <- 3
c(Q = Q, sigma2_ML = Q / n, s2 = Q / (n - p))   # 2.5579、0.0882、0.0984
anova(fit); summary(fit)
new <- data.frame(h = 150, w = 36)
predict(fit, new, interval = "confidence")       # 均值响应
predict(fit, new, interval = "prediction")       # 新个体
sqrt(summary(fit)$r.squared)                     # 复相关系数 R = 0.739
cor(lung$h, lung$w); 1 / (1 - cor(lung$h, lung$w)^2)   # r = 0.742，VIF = 2.23


# 第2章 例15-1：27 例糖尿病（就是 diabetes27_hw.csv，变量改名为 x1–x4、y） -------------------

dd <- read.csv("data/diabetes27_hw.csv")
da <- data.frame(x1 = dd$tc, x2 = dd$tg, x3 = dd$insulin, x4 = dd$hba1c, y = dd$glucose)

fit <- regsubsets(y ~ ., data = da, nbest = 6)
summary(fit)
which.max(summary(fit)$adjr2)                    # 11

model <- lm(y ~ x1 + x2 + x3 + x4, data = da)
AIC(model)                                       # 120.78
extractAIC(model)                                # 5、42.157
step(model)

model_initial <- lm(y ~ 1, data = da)
step(model_initial, scope = list(lower = ~ 1, upper = model), direction = "both")


# 第3章 偏回归图、稳健标准误、岭回归 --------------------------------------------------------

e1 <- resid(lm(x3 ~ x2 + x4, data = da))         # x3 中不能由 x2、x4 线性解释的部分
e2 <- resid(lm(y ~ x2 + x4, data = da))          # y 中不能由 x2、x4 线性解释的部分
plot(e1, e2); abline(lm(e2 ~ e1))
coef(lm(e2 ~ e1))[2]                             # -0.2870 = 完整模型中 x3 的系数
coef(lm(y ~ x2 + x3 + x4, data = da))["x3"]

fit <- lm(y ~ x1 + x2 + x3 + x4, data = da)
coeftest(fit, vcov = vcovHC(fit, type = "HC3"))  # 稳健标准误
car::vif(fit)                                    # 2.19、1.78、1.28、1.27
eigen(cor(da[, 1:4]))$values                     # 2.037、1.031、0.647、0.285

rr <- lm.ridge(y ~ x1 + x2 + x3 + x4, data = da, lambda = seq(0, 20, by = 0.01))
select(rr)                                       # GCV 最小在 8.83
coef(rr)[which.min(rr$GCV), ]                    # 6.325；0.279、0.243、-0.207、0.500

# 相关阵形式的岭回归（笔记附录）
Xs <- as.matrix(da[, 1:4]); R <- cor(Xs); ry <- c(cor(Xs, da$y))
solve(R) %*% ry                                  # 标准化偏回归系数
solve(R + 0.04 * diag(4)) %*% ry                 # k = 0.04 时的标准化岭回归系数

# y 方向的离群点
toy <- read.csv("data/outlier_toy6.csv")
f5 <- lm(y ~ x, data = toy[1:5, ])
coef(f5)                                         # 2.03、2.99
round(cbind(h = hatvalues(f5), r = rstandard(f5), t = rstudent(f5),
            D = cooks.distance(f5)), 4)          # 第 3 点 t = 4.3164，D = 0.339
2 * pt(-abs(rstudent(f5)[3]), 5 - 2 - 1)         # 0.0497
f6 <- lm(y ~ x, data = toy)
round(cbind(h = hatvalues(f6), t = rstudent(f6), D = cooks.distance(f6)), 4)
# 第 6 点 h = 0.8361，t = 0.177，D = 0.1056；第 3 点 t = 4.466

# 偏相关：数学与语文成绩，控制智商
sc <- read.csv("data/score_iq18.csv")
cor(sc)                                           # 数学与语文 0.932
cor(resid(lm(math ~ iq, data = sc)), resid(lm(chinese ~ iq, data = sc)))   # 0.4612
summary(lm(chinese ~ math + iq, data = sc))      # math 的 t = 2.013，P = 0.062


# 第4章 完全随机设计：参数化与对比编码 --------------------------------------------------------

mice <- read.csv("data/mice_oneway30.csv")
x <- mice$x
g <- factor(mice$g, levels = c("NR", "HSP", "HPP"))
lm(x ~ g - 1)                                    # 去掉截距：系数就是各组均数
X_mu <- cbind(1, model.matrix(~ g - 1))          # 设计矩阵：4 列但秩为 3
qr(X_mu)$rank
lm(x ~ X_mu - 1)                                 # 冗余的最后一列系数为 NA
options(contrasts = c("contr.sum", "contr.poly")); lm(x ~ g)   # 和为零编码
options(contrasts = c("contr.treatment", "contr.poly"))         # 恢复默认
lm(x ~ g)
anova(lm(x ~ g))


# 第4章 随机区组设计：兔软骨修复 --------------------------------------------------------------

rb <- read.csv("data/rabbit_block24.csv")
y <- rb$y
treat <- factor(rb$treat, levels = c("A-PRF", "A-PRF+BMSCs", "none"))
block <- factor(rb$block)
mean(y)
aggregate(y, by = list(treat), mean)
X <- model.matrix(~ treat + block)
solve(t(X) %*% X) %*% t(X) %*% y
lm(y ~ treat + block)
anova(lm(y ~ treat + block))


# 第4章 析因设计：甲乙药治疗缺铁性贫血 ----------------------------------------------------------

an <- read.csv("data/anemia_factorial12.csv")
y <- an$y; a <- factor(an$a); b <- factor(an$b)
aggregate(y, by = list(a, b), mean)
aggregate(y, by = list(a), mean)[, 2]            # 1.65、0.90
anova(lm(y ~ a + b + a * b))                     # SS：1.6875、0.9075、0.3675


# 第4章 协方差分析：正常组与超重组的胆固醇 ------------------------------------------------------

ch <- read.csv("data/chol_ancova26.csv")
y <- ch$chol; x <- ch$age; g <- factor(ch$g)
lm(y ~ x + g + x * g)
anova(lm(y ~ x + g + x * g))
fit2 <- lm(y ~ x + g)
summary(fit2)                                    # g 系数 0.8955，SE 0.4057，P = 0.03755
anova(fit2)
fit1 <- lm(y ~ x); fit3 <- lm(y ~ x * g)
anova(fit2, fit3)                                # 斜率是否相同：F = 0.0068，P = 0.935
anova(fit1, fit2)                                # 平行前提下组别：P = 0.03755
anova(fit1, fit2, fit3)                          # 分母都是 fit3 的 MSE：P = 0.04202、0.935
x0 <- mean(x)                                    # 50.23
predict(fit2, data.frame(x = x0, g = factor(levels(g))), se.fit = TRUE)   # 5.491、6.386
confint(fit2)[3, ]                               # 0.056 — 1.735


# 第5章 单组重复测量：10 名患者服药前后体重 ------------------------------------------------------

wt <- read.csv("data/weight_rm10.csv")
d <- as.matrix(wt[, -1])
fit <- lm(d ~ 1)
mauchly.test(fit)                 # 默认检验 Σ 本身是否为 σ²I（d = 5）
mauchly.test(fit, X = ~ 1)        # 检验与常数正交的对比（d = 4）：W = 0.1305

contrasts <- contr.poly(5)        # C：5 × 4，C'C = I，C'1 = 0
S <- cov(resid(fit))
A <- t(contrasts) %*% S %*% contrasts
n <- 10; k <- 5; dd <- k - 1; nu <- n - 1
W <- det(A) / (sum(diag(A)) / dd)^dd; W
chi <- -(nu - (2 * dd^2 + dd + 2) / (6 * dd)) * log(W); chi
1 - pchisq(chi, dd * (dd + 1) / 2 - 1)            # 一阶近似 P = 0.0882
sum(diag(A))^2 / ((k - 1) * sum(diag(A %*% A)))   # GG 系数 0.5397

da <- data.frame(id = factor(rep(1:10, 5)), t = factor(rep(1:5, each = 10)), y = c(d))
print(ezANOVA(data = da, dv = y, wid = id, within = t))


# 第5章 多组重复测量：三种麻醉诱导方法的收缩压 ----------------------------------------------------

an3 <- read.csv("data/anesthesia_rm15.csv")
d <- as.matrix(an3[, c("T0", "T1", "T2", "T3", "T4")])
grp <- factor(an3$g)
da <- data.frame(id = factor(rep(an3$id, 5)), t = factor(rep(0:4, each = 15)),
                 g = rep(grp, 5), y = c(d))
print(ezANOVA(data = da, dv = y, wid = id, within = t, between = g))

S <- crossprod(resid(lm(d ~ grp))) / 12           # 合并组内协方差阵（N - a = 12）
A <- t(contr.poly(5)) %*% S %*% contr.poly(5)
N <- 15; a <- 3; k <- 5; dd <- k - 1; nu <- N - a
W <- det(A) / (sum(diag(A)) / dd)^dd; W            # 0.2931
chi <- -(nu - (2 * dd^2 + dd + 2) / (6 * dd)) * log(W)
1 - pchisq(chi, dd * (dd + 1) / 2 - 1)
sum(diag(A))^2 / ((k - 1) * sum(diag(A %*% A)))    # GG 0.6787

for (lev in levels(grp)) {                         # 各组相对 T0 的配对变化及 95% CI
  dg <- d[grp == lev, ]
  for (j in 2:5) print(t.test(dg[, j] - dg[, 1])$conf.int)
}
