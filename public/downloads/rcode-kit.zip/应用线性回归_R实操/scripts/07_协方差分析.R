# ============================================================
# 07  协方差分析（ANCOVA）：斜率同质性 → 校正模型 → 校正均数与两两比较
# 对应：第三讲第 20–24 页（datasetC_glm）；第四讲第 3–13 页（bp、knee）
#       课堂代码 第三讲.R 后半、第四讲.R 前半
# 数据：datasetC_glm.csv、bp.csv、knee.csv
# 对应笔记：第 7 章
# ============================================================

library(car)
library(emmeans)
library(ggplot2)


# 7.1 为什么要校正：三组年龄不同 --------------------------------------------------------

g <- read.csv("data/datasetC_glm.csv")
g$bmi3 <- factor(g$bmi3, levels = c("normal", "overwt", "obese"))
table(g$bmi3)                                     # 99 / 112 / 29
aggregate(cbind(age, glu) ~ bmi3, data = g, FUN = mean)
anova(lm(age ~ bmi3, data = g))                   # 三组年龄不同：F = 8.76，P = 0.0002
coef(lm(glu ~ age, data = g))["age"]              # 年龄每大 1 岁，血糖高约 0.04


# 7.2 第一步：斜率同质性（平行性）检验 ------------------------------------------------------

# 各组单独拟合的斜率
sapply(split(g, g$bmi3), function(s) coef(lm(glu ~ age, data = s))["age"])
# 比较"共同斜率"与"各组不同斜率"两个模型：P > 0.05 才能继续
m_par <- lm(glu ~ bmi3 + age, data = g)
m_int <- lm(glu ~ bmi3 * age, data = g)
anova(m_par, m_int)                               # F = 0.0995，P = 0.905

ggplot(g, aes(age, glu, colour = bmi3)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm", se = FALSE, formula = y ~ x) +
  scale_colour_manual(values = c("#0072B2", "#D55E00", "#009E73")) + theme_bw()


# 7.3 第二步：建立协方差分析模型 -----------------------------------------------------------

summary(m_par)
# anova() 是顺序平方和：协变量必须放在分组前面，分组那一行才是"校正年龄后"的检验
anova(lm(glu ~ age + bmi3, data = g))             # 正确：bmi3 一行是校正后的
anova(lm(glu ~ bmi3 + age, data = g))             # bmi3 一行是未校正的（= 单因素方差分析）
Anova(m_par, type = "II")                         # 与顺序无关，推荐

# 粗差与校正差并排：差值缩小（控混杂），标准误也变小（提精度）
m_crude <- lm(glu ~ bmi3, data = g)
round(rbind(crude    = coef(summary(m_crude))[2:3, 1:2],
            adjusted = coef(summary(m_par))[2:3, 1:2]), 3)
c(sigma_crude = sigma(m_crude), sigma_adj = sigma(m_par))
c(R2_crude = summary(m_crude)$r.squared, R2_adj = summary(m_par)$r.squared)


# 7.4 第三步：校正均数（把三组都放到总平均年龄 52.6 岁） -------------------------------------

emm <- emmeans(m_par, ~ bmi3)
emm                                               # 4.948 / 5.617 / 5.915
mean(g$age)
# 等价写法：在总平均年龄处预测
predict(m_par, newdata = data.frame(bmi3 = levels(g$bmi3), age = mean(g$age)))
tapply(g$glu, g$bmi3, mean)                       # 粗均数 4.838 / 5.681 / 6.041

# 手算：合并组内斜率 b_w = Σ lxy / Σ lxx；校正均数 = 组均数 - b_w × (组年龄均数 - 总年龄均数)
lxy <- sum(sapply(split(g, g$bmi3), function(s) sum((s$age - mean(s$age)) * (s$glu - mean(s$glu)))))
lxx <- sum(sapply(split(g, g$bmi3), function(s) sum((s$age - mean(s$age))^2)))
b_w <- lxy / lxx
c(b_w = b_w, from_lm = coef(m_par)["age"])        # 0.0332
tapply(g$glu, g$bmi3, mean) - b_w * (tapply(g$age, g$bmi3, mean) - mean(g$age))


# 7.5 校正均数的两两比较 -----------------------------------------------------------------------

pairs(emm, adjust = "tukey")
pairs(emm, adjust = "bonferroni")
confint(pairs(emm, adjust = "bonferroni"))
contrast(emm, method = "trt.vs.ctrl", ref = "normal")   # 都与正常组比（Dunnett）


# 7.6 画平行线 ---------------------------------------------------------------------------------

grid <- expand.grid(age = seq(min(g$age), max(g$age), length.out = 50),
                    bmi3 = levels(g$bmi3))
grid$fit <- predict(m_par, newdata = grid)
ggplot(g, aes(age, glu, colour = bmi3)) +
  geom_point(alpha = 0.5) +
  geom_line(data = grid, aes(y = fit), linewidth = 1) +
  geom_vline(xintercept = mean(g$age), linetype = 2, colour = "grey50") +
  scale_colour_manual(values = c("#0072B2", "#D55E00", "#009E73")) + theme_bw()


# 7.7 课件练习 4 后半：把 age 切成三组再做，结果差多少 ------------------------------------------

g$age3 <- cut(g$age, quantile(g$age, 0:3 / 3), include.lowest = TRUE)
m_cut <- lm(glu ~ bmi3 + age3, data = g)
round(rbind(age_continuous = coef(m_par)[c("bmi3overwt", "bmi3obese")],
            age_3groups    = coef(m_cut)[c("bmi3overwt", "bmi3obese")]), 3)
c(sigma_cont = sigma(m_par), sigma_cut = sigma(m_cut))
# 切组后组内仍有年龄差，校正不彻底，残差也更大：协变量连续就保持连续


# 7.8 第四讲例子：两种降压方案，基线不齐 -------------------------------------------------------

bp <- read.csv("data/bp.csv", fileEncoding = "UTF-8")
bp$group <- factor(bp$group, levels = c("方案A", "方案B"), labels = c("A", "B"))
aggregate(cbind(base, post) ~ group, data = bp, FUN = mean)
# A：158 → 137；B：142 → 131。基线差 15.8 mmHg

t.test(post ~ group, data = bp, var.equal = TRUE)          # 只比终点：A 反而更高
t.test(I(base - post) ~ group, data = bp, var.equal = TRUE)  # 比降幅：A 降得多

fit_full <- lm(post ~ group * base, data = bp)
anova(fit_full)                                   # 交互 P = 0.929，平行
fit <- lm(post ~ base + group, data = bp)         # 协变量放前面
anova(fit)                                        # group：校正后的 F
Anova(fit, type = "II")
anova(lm(post ~ group + base, data = bp))         # 顺序反了：group 一行 F = 14.15 是未校正的
summary(fit)
emm_bp <- emmeans(fit, ~ group)
emm_bp                                            # 校正均数：A 129.2，B 138.6
pairs(emm_bp)                                     # A - B = -9.42，t = -5.04
# 结论反转：校正基线后 A 方案的用药后血压低 9.4 mmHg


# 7.9 前提检查 -----------------------------------------------------------------------------------

t.test(base ~ group, data = bp, var.equal = TRUE)  # 协变量组间差异（随机化研究里应只是偶然）
anova(fit, update(fit, . ~ . + I(base^2)))         # 线性
shapiro.test(resid(fit))                           # 残差正态
leveneTest(resid(fit) ~ bp$group)                  # 方差齐
outlierTest(fit)


# 7.10 第四讲练习数据 knee.csv：两组术前、术后功能评分 ------------------------------------------

kn <- read.csv("data/knee.csv", fileEncoding = "UTF-8")
kn$group <- factor(kn$group)
aggregate(cbind(pre, post) ~ group, data = kn, FUN = mean)
anova(lm(post ~ group * pre, data = kn))           # 先看平行性
fit_kn <- lm(post ~ pre + group, data = kn)
Anova(fit_kn, type = "II")
emmeans(fit_kn, ~ group)
pairs(emmeans(fit_kn, ~ group))
# 三组的版本（knee3.csv）是作业四第 1 题，见 homework/hw4_协方差分析与重复测量.R
