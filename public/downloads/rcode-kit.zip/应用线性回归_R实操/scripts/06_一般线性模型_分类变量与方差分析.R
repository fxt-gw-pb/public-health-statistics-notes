# ============================================================
# 06  一般线性模型：t 检验、方差分析都是 lm()
#     哑变量与参照组、对比编码、随机区组、析因设计与交互
# 对应：第三讲《从回归到一般线性模型》第 1–19 页；课堂代码 第三讲.R 前半；析因变异分解.docx
# 数据：MASS::birthwt（R 自带）、glucose_block.csv、sbp_factorial2x2.csv、datasetC_glm.csv
# 对应笔记：第 6 章
# ============================================================

library(MASS)       # birthwt
library(car)        # Anova
library(emmeans)    # 单元格均数、简单效应
library(ggplot2)


# 6.1 两样本 t 检验 = 只有一个 0/1 列的回归 ----------------------------------------

bw <- birthwt                                    # 189 名产妇
str(bw[, c("lwt", "bwt")])                       # lwt 末次月经时体重（磅），bwt 出生体重（克）
bw$lwt_group <- cut(bw$lwt, breaks = c(-Inf, 110, Inf))   # (-Inf,110] 与 (110,Inf]
table(bw$lwt_group)

var.test(bwt ~ lwt_group, data = bw)             # 方差齐性
t.test(bwt ~ lwt_group, data = bw, var.equal = TRUE)
fit_t <- lm(bwt ~ lwt_group, data = bw)
summary(fit_t)
# 截距 2656.34 = 参照组（≤110 磅）均数；系数 400.58 = 两组均数差；t、P 与 t 检验完全相同
tapply(bw$bwt, bw$lwt_group, mean)
anova(fit_t)                                     # F = t²
coef(summary(fit_t))[2, "t value"]^2

head(model.matrix(fit_t))                        # 设计矩阵：一列 1，一列 0/1


# 6.2 分类变量不能当数字用 ----------------------------------------------------------

bw$group_num <- ifelse(bw$lwt > 110, 2, 1)       # 编成 1/2 的数字
coef(lm(bwt ~ group_num, data = bw))             # 两组时碰巧斜率还是均数差……
bw$lwt4 <- cut(bw$lwt, breaks = c(-Inf, 110, 130, 150, Inf))
bw$lwt4_num <- as.integer(bw$lwt4)               # 4 组编成 1/2/3/4
coef(lm(bwt ~ lwt4_num, data = bw))              # 只剩一个斜率：强加了"等距、线性"
coef(lm(bwt ~ lwt4, data = bw))                  # 正确：3 个哑变量，各组自由


# 6.3 单因素方差分析与参照组 ------------------------------------------------------------

fit4 <- lm(bwt ~ lwt4, data = bw)
summary(fit4)          # 截距 = (-Inf,110] 组均数；其余 = 各组与参照组之差
anova(fit4)            # 整体 F 检验：4 组均数是否全相同
tapply(bw$bwt, bw$lwt4, mean)

# 换参照组：两种写法
bw$lwt4_r <- relevel(bw$lwt4, ref = "(150, Inf]")
coef(lm(bwt ~ lwt4_r, data = bw))
# 注意：levels 里的名字要和 levels(bw$lwt4) 一字不差，"(150, Inf]" 中间有空格
levels(bw$lwt4)
anova(lm(bwt ~ lwt4_r, data = bw))   # 系数变了，整体 F、R²、拟合值都不变

# 多重比较
fit_aov <- aov(bwt ~ lwt4, data = bw)
TukeyHSD(fit_aov)
pairwise.t.test(bw$bwt, bw$lwt4, p.adjust.method = "bonferroni")
pairs(emmeans(fit4, ~ lwt4), adjust = "tukey")


# 6.4 连续、二分、四分：用 AIC 比较不嵌套的模型 ---------------------------------------------

c(continuous = AIC(lm(bwt ~ lwt, data = bw)),
  two_groups = AIC(fit_t),
  four_groups = AIC(fit4))
# 前提：同一因变量、同一批 189 人、都用最大似然；满足即可比，不要求嵌套


# 6.5 对比编码：处理编码 vs 和为零编码 ------------------------------------------------------

contrasts(bw$lwt4)                               # 默认 contr.treatment（0/1 哑变量）
options(contrasts = c("contr.sum", "contr.poly"))
coef(lm(bwt ~ lwt4, data = bw))                  # 截距 = 各组均数的平均；系数 = 各组效应 αi
mean(tapply(bw$bwt, bw$lwt4, mean))
options(contrasts = c("contr.treatment", "contr.poly"))   # 用完恢复默认！


# 6.6 随机区组设计：处理 + 区组，两者都当因子 ---------------------------------------------------

gb <- read.csv("data/glucose_block.csv")         # 8 人 × 4 个放置时间
gb$time    <- factor(gb$time_min)
gb$subject <- factor(gb$subject)
fit_rb <- lm(glucose ~ time + subject, data = gb)
anova(fit_rb)          # time：F = 78.49，P = 1.4e-11；subject 一行是区组
coef(fit_rb)           # 截距 = 区组 1、时间 0 的拟合值；time 系数 = 与 0 分钟之差
head(model.matrix(fit_rb), 10)

# 不控制区组，区组变异全进了误差：F 变小
anova(lm(glucose ~ time, data = gb))


# 6.7 2×2 析因设计：交互作用 ------------------------------------------------------------------

f2 <- read.csv("data/sbp_factorial2x2.csv")
f2$a <- factor(f2$a); f2$b <- factor(f2$b)
fit_ab <- lm(sbp_drop ~ a * b, data = f2)
anova(fit_ab)          # 交互 F = 53.79，P = 3.7e-9：两药协同

# 单元格均数与边际均数
with(f2, tapply(sbp_drop, list(A = a, B = b), mean))
aggregate(sbp_drop ~ a + b, data = f2, FUN = mean)

# 交互图：两种画法
with(f2, interaction.plot(a, b, sbp_drop, type = "b", pch = c(1, 19),
                          xlab = "A", ylab = "SBP drop", trace.label = "B"))
ggplot(f2, aes(a, sbp_drop, colour = b, group = b)) +
  stat_summary(fun = mean, geom = "point", size = 3) +
  stat_summary(fun = mean, geom = "line", linewidth = 1) +
  scale_colour_manual(values = c("#0072B2", "#D55E00")) +
  labs(x = "A drug", y = "SBP drop (mmHg)", colour = "B drug") + theme_bw()


# 6.8 手算析因的平方和分解（析因变异分解.docx 那张表） ----------------------------------------

y <- f2$sbp_drop; gm <- mean(y); nc <- 12
cm <- with(f2, tapply(sbp_drop, list(a, b), mean))      # 2×2 单元格均数
am <- rowMeans(cm); bm <- colMeans(cm)                   # 边际均数
SSA  <- 2 * nc * sum((am - gm)^2)
SSB  <- 2 * nc * sum((bm - gm)^2)
SSAB <- nc * sum((cm - outer(am, rep(1, 2)) - outer(rep(1, 2), bm) + gm)^2)
SST  <- sum((y - gm)^2)
SSE  <- SST - SSA - SSB - SSAB
round(c(SSA = SSA, SSB = SSB, SSAB = SSAB, SSE = SSE, SST = SST), 3)
F_AB <- (SSAB / 1) / (SSE / (4 * (nc - 1)))
c(F = F_AB, P = pf(F_AB, 1, 44, lower.tail = FALSE))

# "无交互"时各格的预测均数 = 总均数 + A 效应 + B 效应（docx 里括号中的 ±5.16、±3.49）
outer(am, rep(1, 2)) + outer(rep(1, 2), bm) - gm


# 6.9 III 型平方和：必须先设和为零编码 ---------------------------------------------------------

options(contrasts = c("contr.sum", "contr.poly"))
Anova(lm(sbp_drop ~ a * b, data = f2), type = "III")   # 平衡设计：与 anova() 相同
options(contrasts = c("contr.treatment", "contr.poly"))
# 如果忘了改编码就做 III 型，主效应检验的是"另一因素在参照水平时"的效应，结果会错
Anova(lm(sbp_drop ~ a * b, data = f2), type = "III")   # 对比一下：a、b 两行变了


# 6.10 交互显著后：简单效应 -----------------------------------------------------------------------

emm_ab <- emmeans(fit_ab, ~ a | b)        # 固定 B，比较 A
pairs(emm_ab)
emm_ba <- emmeans(fit_ab, ~ b | a)        # 固定 A，比较 B
pairs(emm_ba)
contrast(emmeans(fit_ab, ~ a * b), interaction = "pairwise")   # 交互对比本身


# 6.11 课件第 25 页四道练习（datasetC_glm.csv） ---------------------------------------------------

g <- read.csv("data/datasetC_glm.csv")
g$sex  <- factor(g$sex)
g$bmi3 <- factor(g$bmi3, levels = c("normal", "overwt", "obese"))
g$ov   <- factor(g$ov)

# 练习 1：glu ~ sex，t 检验与回归逐项核对，验证 t² = F，写出设计矩阵前 3 行
t.test(glu ~ sex, data = g, var.equal = TRUE)
m1 <- lm(glu ~ sex, data = g)
summary(m1)
c(t2 = coef(summary(m1))[2, 3]^2, F = anova(m1)[1, "F value"])
model.matrix(m1)[1:3, ]

# 练习 2：glu ~ bmi3，把参照组换成 obese，哪些变、哪些不变
m2a <- lm(glu ~ bmi3, data = g)
m2b <- lm(glu ~ relevel(bmi3, ref = "obese"), data = g)
coef(m2a); coef(m2b)                                   # 系数变了
c(anova(m2a)[1, "F value"], anova(m2b)[1, "F value"])   # F 不变
all.equal(fitted(m2a), fitted(m2b))                    # 拟合值不变

# 练习 3：glu ~ sex * ov，交互图与简单效应
m3 <- lm(glu ~ sex * ov, data = g)
anova(m3)                                              # 不平衡：I 型平方和依赖顺序
options(contrasts = c("contr.sum", "contr.poly"))
Anova(lm(glu ~ sex * ov, data = g), type = "III")
options(contrasts = c("contr.treatment", "contr.poly"))
Anova(m3, type = "II")
with(g, interaction.plot(ov, sex, glu, type = "b", pch = c(1, 19)))
pairs(emmeans(m3, ~ ov | sex))                         # 两个简单效应
emmeans(m3, ~ sex * ov)

# 练习 4：协方差分析 glu ~ bmi3 + age，见脚本 07 第 7.1–7.5 节
