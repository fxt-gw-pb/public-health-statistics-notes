# ============================================================
# 08  重复测量方差分析：单组 → 多组；球形检验与 GG/HF 校正；简单效应
# 对应：第四讲第 14–35 页；课堂代码 第四讲.R 后半
# 数据：dm.csv（宽型，40 例 2 型糖尿病 × 3 个时点 HbA1c）、df_long.csv（同一数据的长型）
# 对应笔记：第 8 章
# ============================================================

library(tidyr)
library(afex)       # aov_ez()：自动给出 Mauchly 检验与 GG/HF 校正
library(emmeans)
library(ggplot2)


# 8.1 数据：宽型转长型，时间与组别设为因子 -------------------------------------------------

dm <- read.csv("data/dm.csv", fileEncoding = "UTF-8")
head(dm)
dl <- pivot_longer(dm, cols = c(hba1c_0, hba1c_3, hba1c_6),
                   names_to = "time", values_to = "hba1c")
dl$time  <- factor(dl$time, levels = c("hba1c_0", "hba1c_3", "hba1c_6"),
                   labels = c("T0", "M3", "M6"))
dl$group <- factor(dl$group)
dl$id    <- factor(dl$id)
str(dl)

# data/df_long.csv 就是课堂上已经转好的长型，二者内容一样
dl2 <- read.csv("data/df_long.csv", fileEncoding = "UTF-8")
all.equal(dl2$hba1c, dl$hba1c)


# 8.2 第一步：描述与轨迹图 ---------------------------------------------------------------

aggregate(hba1c ~ group + time, data = dl,
          FUN = function(x) round(c(mean = mean(x), sd = sd(x)), 2))
# A 药组 8.21 → 7.01 → 6.66；B 药组 8.80 → 8.01 → 7.66
# （课件第 31 页折线图上的 8.62、7.62 等数字与数据不符，以第 24 页表格为准）

ggplot(dl, aes(time, hba1c, colour = group, group = group)) +
  stat_summary(fun = mean, geom = "line", linewidth = 1) +
  stat_summary(fun.data = mean_se, geom = "errorbar", width = 0.1) +  # 均数 ± 标准误
  scale_colour_manual(values = c("#0072B2", "#D55E00")) + theme_bw()
# 个体轨迹（意大利面图）：看个体差异有多大
ggplot(dl, aes(time, hba1c, group = id)) + geom_line(colour = "grey60") +
  facet_wrap(~ group) + theme_bw()


# 8.3 单组重复测量：A 药组 20 人 ------------------------------------------------------------

dA <- droplevels(subset(dl, group == "A药组"))
mod1 <- aov_ez(id = "id", dv = "hba1c", data = dA, within = "time")
summary(mod1)       # 含 Mauchly 检验（W = 0.802，P = 0.137）与 GG、HF 校正
anova(mod1, correction = "none")    # 未校正：F = 156.4
anova(mod1, correction = "GG")      # GG 校正：自由度乘以 ε = 0.834
anova(mod1, correction = "HF")

# 等价写法：aov() + Error()（不会自动做球形检验和校正）
summary(aov(hba1c ~ time + Error(id / time), data = dA))


# 8.4 单组的变异分解（手算） -------------------------------------------------------------------

Y  <- as.matrix(dm[dm$group == "A药组", c("hba1c_0", "hba1c_3", "hba1c_6")])
n  <- nrow(Y); k <- ncol(Y); gm <- mean(Y)
SS_total   <- sum((Y - gm)^2)
SS_time    <- n * sum((colMeans(Y) - gm)^2)
SS_subject <- k * sum((rowMeans(Y) - gm)^2)
SS_error   <- SS_total - SS_time - SS_subject
round(c(time = SS_time, subject = SS_subject, error = SS_error, total = SS_total), 3)
F_time <- (SS_time / (k - 1)) / (SS_error / ((n - 1) * (k - 1)))
c(F = F_time, P = pf(F_time, k - 1, (n - 1) * (k - 1), lower.tail = FALSE))
# 受试者间变异被单独剥离，误差只剩"同一人内部"的波动，所以 F 很大


# 8.5 球形假设：差值方差、Mauchly W、GG 与 HF 系数（手算） -------------------------------------

S <- cov(Y)
round(S, 3)
D <- cbind(d12 = Y[, 1] - Y[, 2], d13 = Y[, 1] - Y[, 3], d23 = Y[, 2] - Y[, 3])
round(apply(D, 2, var), 3)          # 0.117 / 0.245 / 0.151：球形要求三者相等

C  <- rbind(c(1, -1, 0) / sqrt(2),  # 正交、单位化的对比矩阵（k - 1 行）
            c(1, 1, -2) / sqrt(6))
Sc <- C %*% S %*% t(C)
p  <- nrow(Sc); nu <- n - 1          # nu：S 的自由度
W   <- det(Sc) / (sum(diag(Sc)) / p)^p
chi <- -(nu - (2 * p^2 + p + 2) / (6 * p)) * log(W)
df  <- p * (p + 1) / 2 - 1
c(W = W, chi2 = chi, df = df, P = pchisq(chi, df, lower.tail = FALSE))

lam <- eigen(Sc)$values
eps_gg <- sum(lam)^2 / (p * sum(lam^2))                        # Greenhouse–Geisser
eps_hf <- min(1, (n * p * eps_gg - 2) / (p * (nu - p * eps_gg)))   # Huynh–Feldt（单组）
c(GG = eps_gg, HF = eps_hf)

# 基础 R 也能做 Mauchly 检验：X = ~1 表示检验与常数正交的对比
mauchly.test(lm(Y ~ 1), X = ~ 1)

# 校正就是把两个自由度都乘以 ε，F 值不变
pf(F_time, (k - 1) * eps_gg, (n - 1) * (k - 1) * eps_gg, lower.tail = FALSE)


# 8.6 多组重复测量：药物（组间）× 时间（组内） -------------------------------------------------

mod <- aov_ez(id = "id", dv = "hba1c", data = dl,
              within = "time", between = "group")
summary(mod)
anova(mod, correction = "GG", es = "pes")    # 三个 F：药物 18.28、时间 199.55、交互 5.59

summary(aov(hba1c ~ group * time + Error(id / time), data = dl))   # 两层误差项

# 错误示范：忽略"同一人测三次"，当作独立观测做两因素方差分析
anova(lm(hba1c ~ group * time, data = dl))   # 误差自由度 114，组间比较的 F 被夸大


# 8.7 多组的变异分解（手算） --------------------------------------------------------------------

Yall <- as.matrix(dm[, c("hba1c_0", "hba1c_3", "hba1c_6")])
grp  <- as.integer(factor(dm$group))           # 1 = A，2 = B
N <- nrow(Yall); a <- 2; nn <- N / a; K <- 3; gm <- mean(Yall)
mi  <- as.vector(tapply(rowMeans(Yall), grp, mean))            # 组均数（as.vector 去掉数组属性）
mk  <- colMeans(Yall)                                          # 时点均数
mik <- apply(Yall, 2, function(x) tapply(x, grp, mean))        # 组 × 时点均数
mij <- rowMeans(Yall)                                          # 个体均数
SS_group <- nn * K * sum((mi - gm)^2)
SS_subj  <- K * sum((mij - mi[grp])^2)                         # 受试者间误差（组内个体差异）
SS_time  <- N * sum((mk - gm)^2)
SS_int   <- nn * sum((mik - outer(mi, rep(1, K)) - outer(rep(1, a), mk) + gm)^2)
SS_err   <- sum((Yall - outer(mij, rep(1, K)) - mik[grp, ] + mi[grp])^2)
round(c(group = SS_group, subject = SS_subj, time = SS_time,
        interaction = SS_int, error = SS_err, total = sum((Yall - gm)^2)), 4)
c(F_group = (SS_group / (a - 1)) / (SS_subj / (N - a)),
  F_time  = (SS_time / (K - 1)) / (SS_err / ((N - a) * (K - 1))),
  F_int   = (SS_int / ((a - 1) * (K - 1))) / (SS_err / ((N - a) * (K - 1))))
# 组间效应用"受试者间误差"作分母；时间和交互用"受试者内误差"作分母


# 8.8 多组时的球形检验：用合并组内协方差阵 ----------------------------------------------------------

Sp <- Reduce(`+`, lapply(split(as.data.frame(Yall), grp),
                         function(s) (nrow(s) - 1) * cov(s))) / (N - a)
Sc <- C %*% Sp %*% t(C); nu <- N - a
W   <- det(Sc) / (sum(diag(Sc)) / p)^p
chi <- -(nu - (2 * p^2 + p + 2) / (6 * p)) * log(W)
lam <- eigen(Sc)$values
c(W = W, P = pchisq(chi, p * (p + 1) / 2 - 1, lower.tail = FALSE),
  GG = sum(lam)^2 / (p * sum(lam^2)))
summary(mod)$sphericity.tests                  # 与 afex 输出一致


# 8.9 交互显著后：两个方向的简单效应 ---------------------------------------------------------------

emm1 <- emmeans(mod, ~ time | group)           # ① 组内：固定组别，比较各时点
pairs(emm1, adjust = "bonferroni")
emm2 <- emmeans(mod, ~ group | time)           # ② 组间：固定时点，比较两组
pairs(emm2)
confint(pairs(emm2))

# 交互对比：两组差距在 T0→M3、M3→M6 两个阶段各变了多少
contrast(emmeans(mod, ~ time * group), interaction = c("consec", "pairwise"))


# 8.10 不依赖球形假设的多元检验 ---------------------------------------------------------------------

summary(mod$Anova, multivariate = TRUE)        # Pillai、Wilks 等
