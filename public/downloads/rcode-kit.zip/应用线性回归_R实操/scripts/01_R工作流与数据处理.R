# ============================================================
# 01  R 工作流与数据处理
# 对应笔记：第 1 章
# 目的：把"读数据 → 看数据 → 改变量 → 汇总 → 宽长转换 → 写公式 → 取结果"
#       这条链走顺。后面每一讲的代码都建立在这些操作上。
# 运行前：在 RStudio 里打开 应用线性回归_R实操.Rproj（工作目录自动是项目根目录）
# 小技巧：Ctrl/Cmd + Shift + O 打开右侧大纲，按小节跳转；
#         Ctrl/Cmd + Enter 运行当前行，Ctrl/Cmd + Shift + Enter 运行整份脚本。
# ============================================================


# 1.1 工作目录与路径 ----------------------------------------------------------

getwd()                         # 应该是 .../应用线性回归_R实操
list.files("data")              # 所有数据都在 data/ 下
file.exists("data/datasetA.csv")

# 课堂代码写的是 read.csv("d://data/a.csv")：那是老师电脑上的绝对路径。
# 在本项目里统一改成相对路径 "data/xxx.csv"，换电脑也不用改。


# 1.2 读入 CSV：read.csv() 的几个参数 -------------------------------------------

d <- read.csv("data/datasetA.csv")          # 默认 header = TRUE、逗号分隔
head(d)

# 中文内容或中文列名的文件，加 fileEncoding = "UTF-8" 最稳（Windows 尤其需要）
bp <- read.csv("data/bp.csv", fileEncoding = "UTF-8")
str(bp)                         # group 是 chr（字符），建模时 R 会自动当因子处理

# 列名是中文、带括号时，check.names = FALSE 保留原样；之后再改成英文短名
f3 <- read.csv("data/sbp_factorial3x3.csv", check.names = FALSE,
               fileEncoding = "UTF-8")
names(f3)
names(f3) <- c("id", "A", "B", "y")
head(f3, 3)

# 课堂代码里的 [, -1]：去掉第 1 列（id 或行号），只留分析变量
read.csv("data/datasetC.csv")[, -1] |> head(3)


# 1.3 看数据：任何分析之前先做的三件事 ------------------------------------------

str(d)            # 每列类型：num / int / chr / Factor
summary(d)        # 最小值、四分位数、均数、最大值，能挡掉单位错、录入错
nrow(d); ncol(d); dim(d)

sapply(d[, -1], mean)            # 对每一列求均数（去掉 id）
sapply(d[, -1], sd)
round(cor(d[, -1]), 3)           # 相关矩阵
colSums(is.na(d))                # 每列缺失数


# 1.4 取子集：$、[ , ]、subset()、which() ----------------------------------------

d$age[1:5]                       # 一列
d[1:3, c("age", "glu")]          # 行、列同时取
d[d$age > 70, ]                  # 条件取行
subset(d, age > 70 & bmi > 28, select = c(id, age, bmi, glu))
which(d$glu == max(d$glu))       # 返回行号
d[-c(1, 2), ] |> nrow()          # 负号 = 删除这些行；回归诊断里删点就这样写


# 1.5 新变量：计算、分组、因子 --------------------------------------------------

d$bmi_c <- d$bmi - mean(d$bmi)                     # 中心化
d$zglu  <- as.numeric(scale(d$glu))                # 标准化（scale 返回矩阵，取成向量）

# cut()：连续变量切组。breaks 是端点，right = TRUE 表示区间 (a, b]
d$agegrp <- cut(d$age, breaks = c(29, 45, 58, 79),
                labels = c("30-45", "46-58", "59-78"))
table(d$agegrp)

# 因子：水平顺序决定"参照组"（第一个水平是参照）
levels(d$agegrp)
d$agegrp2 <- relevel(d$agegrp, ref = "59-78")       # 换参照组
levels(d$agegrp2)
d$agegrp3 <- factor(d$agegrp, levels = c("46-58", "30-45", "59-78"))  # 指定全部顺序
levels(d$agegrp3)

# 字符变量转因子并给水平改名
bp$group <- factor(bp$group, levels = c("方案A", "方案B"), labels = c("A", "B"))
table(bp$group)

# ifelse()：二分类
d$old <- ifelse(d$age >= 60, 1, 0)
table(d$old)


# 1.6 分组汇总：tapply / aggregate / by / split ----------------------------------

tapply(d$glu, d$agegrp, mean)                       # 一个变量、一个分组
aggregate(glu ~ agegrp, data = d, FUN = mean)       # 公式写法，返回数据框
aggregate(cbind(base, post) ~ group, data = bp, FUN = mean)   # 多个变量
aggregate(glu ~ agegrp, data = d,
          FUN = function(x) c(mean = mean(x), sd = sd(x), n = length(x)))

# 层内各拟合一条回归，取斜率（第一讲"分层"的写法）
by(d, d$agegrp, function(s) coef(lm(glu ~ bmi, data = s))[2])
sapply(split(d, d$agegrp), function(s) coef(lm(glu ~ bmi, data = s))[2])


# 1.7 宽型与长型：重复测量必须先转成长型 ----------------------------------------

library(tidyr)
dm <- read.csv("data/dm.csv", fileEncoding = "UTF-8")
head(dm, 3)                                   # 宽型：一人一行，三个时点三列

dl <- pivot_longer(dm, cols = c(hba1c_0, hba1c_3, hba1c_6),
                   names_to = "time", values_to = "hba1c")
dl$time  <- factor(dl$time, levels = c("hba1c_0", "hba1c_3", "hba1c_6"),
                   labels = c("T0", "M3", "M6"))
head(dl, 6)                                   # 长型：一人三行
nrow(dm); nrow(dl)                            # 40 → 120

dw <- pivot_wider(dl, names_from = time, values_from = hba1c)   # 再转回宽型
head(dw, 3)


# 1.8 模型公式：~ 左边是 y，右边是 X 的列 -----------------------------------------
#   y ~ x1 + x2        两个主效应
#   y ~ .              数据框里除 y 外的全部变量
#   y ~ a * b          = a + b + a:b（主效应 + 交互）
#   y ~ a:b            只有交互项
#   y ~ x - 1          去掉截距
#   y ~ x + I(x^2)     公式里做算术要包 I()
#   log(y) ~ x         直接对 y 变换

fit <- lm(glu ~ age + bmi, data = d)
update(fit, . ~ . - age)            # 在原模型上删变量
update(fit, . ~ . + I(bmi^2))       # 加二次项
update(fit, data = d[-1, ])         # 换数据（删点做敏感性分析）
reformulate(c("age", "bmi"), response = "glu")   # 用字符串拼公式

head(model.matrix(glu ~ age + agegrp, data = d))  # 公式实际生成的设计矩阵 X


# 1.9 模型对象里有什么：常用提取函数 --------------------------------------------

names(fit)                  # lm 对象本质是一个 list
coef(fit)                   # 系数
confint(fit)                # 系数 95% CI
vcov(fit)                   # 系数的协方差阵
sigma(fit)                  # 剩余标准差 s
df.residual(fit)            # 残差自由度 n - p - 1
deviance(fit)               # 残差平方和 SSE
nobs(fit)                   # 样本量
head(fitted(fit)); head(resid(fit))
logLik(fit); AIC(fit); BIC(fit)

s <- summary(fit)           # summary 也是 list
s$coefficients              # 系数表（矩阵），等价于 coef(summary(fit))
s$r.squared; s$adj.r.squared; s$fstatistic


# 1.10 不要用 attach()：用 data = 或 with() -------------------------------------
# 课堂代码常写 attach(d)：之后直接用列名。问题是多次 attach 不同数据时
# 同名变量互相遮盖，改了 d 也不会同步。统一改用 data = 参数：

with(d, cor(bmi, glu))      # 临时在 d 里找变量
lm(glu ~ bmi, data = d)     # 建模永远写 data =


# 1.11 保存结果 -----------------------------------------------------------------

dir.create("output", showWarnings = FALSE)
write.csv(aggregate(glu ~ agegrp, data = d, FUN = mean),
          "output/01_agegrp_mean.csv", row.names = FALSE)

pdf("output/01_scatter.pdf", width = 5, height = 4)   # 图存成 PDF
plot(glu ~ bmi, data = d, pch = 19, col = "grey40")
abline(lm(glu ~ bmi, data = d), col = "#0072B2", lwd = 2)
dev.off()

saveRDS(fit, "output/01_fit.rds")          # 模型对象存盘，下次 readRDS() 读回
