# ============================================================
# 04  回归诊断：LINE 四条件、补救办法、离群点与强影响点
# 对应：第二讲《回归诊断》第一关、第三关；课件第 21 页"可以直接抄走的 R 脚本"
# 数据：datasetB.csv（n = 150，模拟数据，故意埋了异方差、共线性、两个异常个体）
# 对应笔记：第 4 章
# ============================================================

library(car)       # ncvTest、durbinWatsonTest、residualPlots、avPlots、influencePlot、outlierTest
library(MASS)      # rlm
library(lmtest)    # coeftest
library(sandwich)  # vcovHC

d <- read.csv("data/datasetB.csv")
str(d)                                      # 最后一列是 id
m <- lm(glu ~ age + bmi + waist, data = d)
summary(m)                                  # R² = 0.459，F = 41.35：看起来不错
n <- nrow(d); p <- 3                        # p = 自变量个数


# 4.1 四张诊断图：plot(m) -----------------------------------------------------------
#   which = 1 残差–拟合值图：看线性（红线是否贴着 0）和等方差（带子宽度）
#   which = 2 正态 Q-Q 图：只看两端
#   which = 3 尺度–位置图：红线上斜 = 方差随拟合值增大
#   which = 5 残差–杠杆图：带 Cook 距离等高线
par(mfrow = c(2, 2)); plot(m); par(mfrow = c(1, 1))
plot(m, which = 4)                          # Cook 距离针状图
plot(m, which = 1, id.n = 3)                # 标出残差最大的 3 个点


# 4.2 正态性 ---------------------------------------------------------------------------

shapiro.test(resid(m))                      # W = 0.900，P = 1.4e-8
qqnorm(rstudent(m)); qqline(rstudent(m))    # 用学生化残差画更合适
qqPlot(m, id = list(n = 2))                 # car 版，带置信带并标出两端的点


# 4.3 等方差 ---------------------------------------------------------------------------

ncvTest(m)                                  # χ² = 57.6，P = 3.2e-14
# 把拟合值四等分，看各段残差的标准差：0.20 → 0.88，约 4 倍
# （课件表格写的是 0.19 → 0.98，分段方式略有不同，结论一样）
q <- cut(fitted(m), quantile(fitted(m), 0:4 / 4), include.lowest = TRUE)
round(tapply(resid(m), q, sd), 2)
spreadLevelPlot(m)                          # 还会建议一个幂变换


# 4.4 独立性 ---------------------------------------------------------------------------
# DW 只对有天然顺序（时间、空间）的数据有意义；本例是横断面数据，行序没有含义
durbinWatsonTest(m)                         # DW = 1.65；P 来自 bootstrap，每次略有不同
dwtest(m)                                   # lmtest 版本
set.seed(1)
durbinWatsonTest(update(m, data = d[sample(n), ]))   # 打乱行序，结果就变：说明它在这里没意义


# 4.5 线性 -------------------------------------------------------------------------------

residualPlots(m)          # 每个自变量一张残差图 + 曲率检验；最后一行 Tukey test 针对整体
crPlots(m)                # 成分 + 残差图（偏残差图），看各自变量是否需要非线性项
avPlots(m)                # 偏回归图（added-variable plot），斜率 = 该变量在全模型里的系数
anova(m, update(m, . ~ . + I(age^2)))      # 怀疑哪个变量弯曲，就加它的二次项检验

# 手工画偏回归图（以 bmi 为例）：两组残差的散点，斜率就是全模型里的 bmi 系数
e_y <- resid(lm(glu ~ age + waist, data = d))
e_x <- resid(lm(bmi ~ age + waist, data = d))
plot(e_x, e_y); abline(lm(e_y ~ e_x), col = "#0072B2", lwd = 2)
c(coef(lm(e_y ~ e_x))[2], coef(m)["bmi"])


# 4.6 方差不齐的三种补救 ------------------------------------------------------------------

# ① 加权最小二乘：|残差| 对拟合值回归，估计每个人的标准差，权重取其平方的倒数
w  <- 1 / fitted(lm(abs(resid(m)) ~ fitted(m)))^2
mw <- lm(glu ~ age + bmi + waist, data = d, weights = w)
summary(mw)
ncvTest(mw)                                 # 补救后必须再查一遍

# ② 稳健（异方差一致）标准误：系数不变，只换标准误
coeftest(m)                                         # 普通标准误
coeftest(m, vcov = vcovHC(m, type = "HC3"))         # 稳健标准误
round(cbind(OLS = sqrt(diag(vcov(m))),
            HC3 = sqrt(diag(vcovHC(m, type = "HC3")))), 4)

# ③ 因变量变换
ml <- lm(log(glu) ~ age + bmi + waist, data = d)
ncvTest(ml)                                 # 改善了，但没根治
# log(y) 模型的系数解释为相对变化：exp(b) - 1
round((exp(coef(ml)[-1]) - 1) * 100, 2)     # 每增 1 单位，血糖变化的百分数

# 三种做法下 bmi 的系数、标准误、P
rbind(OLS = coef(summary(m))["bmi", ],
      WLS = coef(summary(mw))["bmi", ],
      HC3 = coeftest(m, vcov = vcovHC(m, type = "HC3"))["bmi", ])


# 4.7 杠杆值、学生化残差、Cook 距离 -----------------------------------------------------------

inf <- data.frame(id = d$id, h = hatvalues(m), r_int = rstandard(m),
                  r_ext = rstudent(m), D = cooks.distance(m))
head(inf[order(-inf$D), ], 5)               # Cook 距离最大：149 号 0.864，150 号 0.292
head(inf[order(-abs(inf$r_ext)), ], 3)      # 学生化残差最大：150 号 6.85
head(inf[order(-inf$h), ], 3)               # 杠杆值最大：149 号 0.297

# 常用界值（都只是筛子）
c(mean_h = (p + 1) / n, h_cut = 2 * (p + 1) / n, D_cut = 4 / (n - p - 1))
which(hatvalues(m) > 2 * (p + 1) / n)
which(abs(rstudent(m)) > 3)
which(cooks.distance(m) > 4 / (n - p - 1))

influencePlot(m)                            # 横轴杠杆，纵轴学生化残差，圈大小 = Cook D
outlierTest(m)                              # 最大 |学生化残差| 的 Bonferroni 校正 P
summary(influence.measures(m))              # DFBETAS、DFFIT、COVRATIO、Cook、hat 一次给出

d[c(149, 150), ]                            # 回到原始记录：24 岁、BMI 36.2；70 岁、血糖 8.8


# 4.8 Cook 距离与学生化残差的手算 ------------------------------------------------------------

h <- hatvalues(m); e <- resid(m); s <- sigma(m); k <- p + 1
r  <- e / (s * sqrt(1 - h))                          # 内学生化
tt <- r * sqrt((n - k - 1) / (n - k - r^2))          # 外学生化（删除学生化）
D  <- r^2 / k * h / (1 - h)                          # Cook 距离
c(all.equal(r, rstandard(m)), all.equal(tt, rstudent(m)),
  all.equal(D, cooks.distance(m)))

# Cook 距离的定义：删掉第 i 点后，所有拟合值一共挪了多少
i <- 149
yhat_del <- predict(update(m, data = d[-i, ]), newdata = d)
sum((fitted(m) - yhat_del)^2) / (k * s^2)
cooks.distance(m)[i]


# 4.9 敏感性分析：删掉它，结论怎么变 ----------------------------------------------------------

m149 <- update(m, data = d[-149, ])
m150 <- update(m, data = d[-150, ])
tab <- sapply(list(all = m, del149 = m149, del150 = m150), function(x)
  c(coef(x), R2 = summary(x)$r.squared, sigma = sigma(x)))
round(tab, 4)       # bmi 系数 0.067 → 0.124（删 149）；残差 SD 0.544 → 0.474（删 150）


# 4.10 稳健回归：不删点，让异常点自动降权 -------------------------------------------------------

mr <- rlm(glu ~ age + bmi + waist, data = d)            # M 估计（Huber）
summary(mr)
round(mr$w[c(149, 150)], 3)                             # 150 号权重被压得很低
mmm <- rlm(glu ~ age + bmi + waist, data = d, method = "MM")   # 抗高杠杆点更强
round(cbind(OLS = coef(m), Huber = coef(mr), MM = coef(mmm)), 4)


# 4.11 一份诊断清单（拿到新模型可以直接套） -------------------------------------------------------

diag_report <- function(fit) {
  n <- nobs(fit); k <- length(coef(fit))
  cat("Shapiro-Wilk P =", signif(shapiro.test(resid(fit))$p.value, 3), "\n")
  cat("ncvTest P      =", signif(ncvTest(fit)$p, 3), "\n")
  if (k > 2) { cat("VIF:\n"); print(round(vif(fit), 2)) }
  cat("h > 2k/n      :", which(hatvalues(fit) > 2 * k / n), "\n")
  cat("|rstudent| > 3:", which(abs(rstudent(fit)) > 3), "\n")
  cat("Cook D > 4/(n-k):", which(cooks.distance(fit) > 4 / (n - k)), "\n")
  invisible(NULL)
}
diag_report(m)
diag_report(lm(glucose ~ tc + tg + insulin + hba1c,
               data = read.csv("data/diabetes27_hw.csv")))   # 作业二的全模型
