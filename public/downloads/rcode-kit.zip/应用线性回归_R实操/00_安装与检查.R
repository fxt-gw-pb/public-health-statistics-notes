# ============================================================
# 00  第一次打开时运行一次：安装本学习包用到的 R 包，并检查数据是否齐全
# ============================================================

pkgs <- c("car",       # Anova、vif、ncvTest、influencePlot、leveneTest……
          "MASS",      # lm.ridge、rlm、birthwt（R 自带，一般已装）
          "leaps",     # regsubsets 全子集
          "olsrr",     # 按 P 值的逐步回归
          "ppcor",     # 偏相关
          "lmtest", "sandwich",   # 稳健标准误
          "emmeans",   # 校正均数、简单效应、两两比较
          "afex",      # aov_ez 重复测量方差分析
          "ez",        # ezANOVA（课件笔记用）
          "tidyr",     # pivot_longer / pivot_wider
          "ggplot2")
need <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(need)) install.packages(need)
# 国内网络慢时可先换镜像：
# options(repos = c(CRAN = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))

print(sapply(pkgs, requireNamespace, quietly = TRUE))

# 检查工作目录与数据
stopifnot(file.exists("data/datasetA.csv"))   # 不通过 = 没有从 .Rproj 打开
print(list.files("data", pattern = "\\.csv$"))
dir.create("output", showWarnings = FALSE)
cat("R 版本：", R.version.string, "\n")
