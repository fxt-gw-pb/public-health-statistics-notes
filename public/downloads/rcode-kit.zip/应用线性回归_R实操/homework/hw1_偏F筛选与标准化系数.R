# 应用线性回归 课后作业（一）
# 数据：data/diabetes27_hw.csv（在学习包根目录运行，即打开 .Rproj 后运行）
# 变量：tc 总胆固醇, tg 甘油三酯, insulin 空腹胰岛素, hba1c 糖化血红蛋白, glucose 空腹血糖

d <- read.csv("data/diabetes27_hw.csv")
head(d)
str(d)
summary(d)

# 核对：与课件给出的均数±标准差一致
round(sapply(d[, -1], mean), 2)
round(sapply(d[, -1], sd), 2)
round(cor(d[, -1]), 3)


# ---------- 1. 初始模型 + drop1 偏F检验 ----------
full <- lm(glucose ~ tc + tg + insulin + hba1c, data = d)
summary(full)

# 第1步：对4个变量分别做偏F检验
drop1(full, test = "F")
# tc 的 F 最小（F = 0.15，P = 0.70），剔除

# 第2步
m3 <- update(full, . ~ . - tc)
drop1(m3, test = "F")
# 剩下三个变量 P 均 < 0.05，停止

anova(m3, full)        # 与 drop1 中 tc 那一行相同
t.full <- coef(summary(full))[, "t value"]
t.full^2               # 单个变量的偏F = t^2


# ---------- 2. 最终模型的偏回归系数 ----------
fit <- m3
summary(fit)
confint(fit)
summary(fit)$r.squared
summary(fit)$adj.r.squared
summary(fit)$sigma


# ---------- 3. 标准化偏回归系数 ----------
# b* = b * SD(x) / SD(y)
b <- coef(fit)[-1]
sx <- sapply(d[, names(b)], sd)
sy <- sd(d$glucose)
bstar <- b * sx / sy
round(bstar, 3)
round(confint(fit)[-1, ] * sx / sy, 3)    # 对应的95%CI（同一比例缩放）

# 验证：把 y 和 x 全部标准化后再回归，结果一样
dz <- as.data.frame(scale(d[, -1]))
coef(lm(glucose ~ tg + insulin + hba1c, data = dz))

# t 值 = b* × sqrt(1 - Rj^2) 的比例关系，顺便看一下各变量的 VIF
vif <- sapply(names(b), function(v) {
  r2 <- summary(lm(reformulate(setdiff(names(b), v), v), data = d))$r.squared
  1 / (1 - r2)
})
round(vif, 3)


# ---------- 4. 自变量取均值时的 95%CI 与 95%PI ----------
new <- data.frame(tg = mean(d$tg), insulin = mean(d$insulin), hba1c = mean(d$hba1c))
new
predict(fit, new, interval = "confidence")
predict(fit, new, interval = "prediction")

# 手算核对
p <- predict(fit, new, se.fit = TRUE)
s <- summary(fit)$sigma
tq <- qt(0.975, df = fit$df.residual)
c(yhat = p$fit, se.mean = p$se.fit, s.over.sqrtn = s / sqrt(nrow(d)),
  se.indiv = sqrt(s^2 + p$se.fit^2), t = tq)


# ---------- 思考1：总胆固醇 ----------
summary(lm(glucose ~ tc, data = d))

# tc 对其余三个自变量回归，看能被解释多少
summary(lm(tc ~ tg + insulin + hba1c, data = d))$r.squared

# 偏相关：两组残差的相关
e.y  <- resid(lm(glucose ~ tg + insulin + hba1c, data = d))
e.tc <- resid(lm(tc ~ tg + insulin + hba1c, data = d))
cor(e.y, e.tc)
coef(lm(e.y ~ e.tc))[2]      # 等于全模型中 tc 的系数

# 依次加入其他变量，看 tc 的系数怎么变
round(rbind(
  "tc"                  = coef(summary(lm(glucose ~ tc, d)))["tc", ],
  "tc+tg"               = coef(summary(lm(glucose ~ tc + tg, d)))["tc", ],
  "tc+hba1c"            = coef(summary(lm(glucose ~ tc + hba1c, d)))["tc", ],
  "tc+insulin"          = coef(summary(lm(glucose ~ tc + insulin, d)))["tc", ],
  "tc+tg+insulin+hba1c" = coef(summary(full))["tc", ]
), 4)
confint(full)["tc", ]

# 25号：tc、tg 都远高于其他人
d[25, ]
hatvalues(lm(glucose ~ tc, data = d))[25]
summary(lm(glucose ~ tc, data = d[-25, ]))$coefficients
summary(update(full, data = d[-25, ]))$coefficients


# ---------- 思考2：逐步法 ----------
# (a) 前进法 alpha_in = 0.05：
m0 <- lm(glucose ~ 1, data = d)
sc <- ~ tc + tg + insulin + hba1c
add1(m0, sc, test = "F")                                  # hba1c 进入
add1(update(m0, . ~ . + hba1c), sc, test = "F")           # tc 进入
add1(update(m0, . ~ . + hba1c + tc), sc, test = "F")      # 最小 P = 0.088 > 0.05，停止
drop1(lm(glucose ~ tc + hba1c, data = d), test = "F")
summary(lm(glucose ~ tc + hba1c, data = d))$adj.r.squared

# (b) 按 AIC 的逐步法
step(m0, scope = sc, direction = "both")
step(full, direction = "backward")

# (c) bootstrap 看后退法结果是否稳定（alpha_out = 0.05）
backward <- function(dat, alpha = 0.05) {
  vars <- c("tc", "tg", "insulin", "hba1c")
  repeat {
    if (length(vars) == 0) break
    m <- lm(reformulate(vars, "glucose"), data = dat)
    pv <- drop1(m, test = "F")[-1, "Pr(>F)"]
    if (max(pv) < alpha) break
    vars <- vars[-which.max(pv)]
  }
  vars
}
backward(d)

set.seed(2026)
B <- 1000
sel <- replicate(B, {
  i <- sample(nrow(d), replace = TRUE)
  paste(backward(d[i, ]), collapse = "+")
})
sort(table(sel), decreasing = TRUE)[1:6] / B
inc <- sapply(c("tc", "tg", "insulin", "hba1c"), function(v) mean(grepl(v, sel)))
round(inc, 3)
