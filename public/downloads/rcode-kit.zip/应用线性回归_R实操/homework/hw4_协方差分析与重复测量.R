# 应用线性回归 课后作业（四）
# 数据：knee3.csv（第 1 题）、stroke.csv（第 2 题）
# 数据在 data/，图形输出到 output/hw4（在学习包根目录运行）

library(car)
library(emmeans)
library(afex)
library(tidyr)

okabe <- c("#0072B2", "#D55E00", "#009E73")
dir.create("output/hw4", recursive = TRUE, showWarnings = FALSE)
desc <- function(x)
  round(c(mean = mean(x), sd = sd(x), n = length(x)), 2)

# ============================================================
# 第 1 题  三种康复方案的协方差分析
# ============================================================
k <- read.csv("data/knee3.csv", fileEncoding = "UTF-8")
# A 常规康复，B 强化康复，C 机器人辅助
k$group <- factor(k$group, labels = c("A", "B", "C"))
str(k)

# ---------- 描述 ----------
aggregate(cbind(pre, post) ~ group, data = k, FUN = desc)
k$chg <- k$post - k$pre
aggregate(chg ~ group, data = k, FUN = desc)
anova(lm(pre ~ group, data = k))                 # 术前评分组间比较
sapply(split(k, k$group), function(s) cor(s$pre, s$post))

# 不校正，直接比较术后评分
anova(lm(post ~ group, data = k))
pairwise.t.test(k$post, k$group, p.adjust.method = "bonferroni")

# ---------- 第一步：斜率同质性 ----------
fit_full <- lm(post ~ pre * group, data = k)
anova(fit_full)                                  # 看 pre:group 一行
sapply(split(k, k$group), function(s) coef(lm(post ~ pre, data = s)))

# ---------- 第二、三步：协方差分析 ----------
fit <- lm(post ~ pre + group, data = k)
anova(fit)                        # 序贯平方和：pre 要放在 group 前面
Anova(fit, type = 2)              # II 型平方和，group 一行与上面相同
anova(lm(post ~ group + pre, data = k))          # 顺序反了，group 未校正
summary(fit)
confint(fit)
a1 <- Anova(fit, type = 2)
ss <- a1[, "Sum Sq"]
ss[2] / (ss[2] + ss[3])                          # group 的偏 eta^2

# 其他前提
anova(fit, lm(post ~ pre + I(pre^2) + group, data = k))   # 线性
shapiro.test(resid(fit))                                  # 残差正态
leveneTest(resid(fit) ~ k$group)                          # 方差齐
outlierTest(fit)
round(sort(cooks.distance(fit), decreasing = TRUE)[1:3], 3)

# ---------- 校正均值与两两比较 ----------
mean(k$pre)                                      # 校正到的术前评分
emm <- emmeans(fit, ~ group)
emm
pairs(emm, adjust = "bonferroni")
confint(pairs(emm, adjust = "bonferroni"))
pairs(emm, adjust = "tukey")                     # 换用 Tukey 法

# 斜率接近 1：与差值（post - pre）分析对照
anova(lm(chg ~ group, data = k))
pairwise.t.test(k$chg, k$group, p.adjust.method = "bonferroni")

# ---------- 图 1 ----------
pdf("output/hw4/fig1_ancova.pdf", width = 7.2, height = 3.4,
    useDingbats = FALSE)
par(mfrow = c(1, 2), mar = c(4.2, 4.2, 2, 1), mgp = c(2.4, 0.7, 0),
    cex = 0.82, las = 1)
pchs <- c(21, 24, 22)
plot(post ~ pre, data = k, type = "n", xlab = "Pre-operative score",
     ylab = "6-month score", main = "(a) Separate regression lines",
     font.main = 1, cex.main = 1)
abline(v = mean(k$pre), col = "#C9C7C1", lty = 2)
for (i in 1:3) {
  s <- k[k$group == levels(k$group)[i], ]
  points(s$pre, s$post, pch = pchs[i], bg = adjustcolor(okabe[i], 0.55),
         col = okabe[i], cex = 0.9)
  xs <- range(s$pre)
  b <- coef(lm(post ~ pre, data = s))
  lines(xs, b[1] + b[2] * xs, col = okabe[i], lwd = 2.2)
}
legend("topleft", c("A Routine", "B Intensive", "C Robot-assisted"),
       col = okabe, pt.bg = adjustcolor(okabe, 0.55), pch = pchs,
       lwd = 2.2, bty = "n")
raw <- t(sapply(split(k$post, k$group), function(x) {
  h <- qt(0.975, length(x) - 1) * sd(x) / sqrt(length(x))
  mean(x) + c(0, -1, 1) * h
}))
adj <- as.matrix(summary(emm)[, c("emmean", "lower.CL", "upper.CL")])
plot(NA, xlim = c(0.5, 3.5), ylim = c(70, 88), xaxt = "n",
     xlab = "Group", ylab = "6-month score",
     main = "(b) Unadjusted vs adjusted means",
     font.main = 1, cex.main = 1)
axis(1, at = 1:3, labels = c("A", "B", "C"))
xl <- 1:3 - 0.13; xr <- 1:3 + 0.13
arrows(xl, raw[, 2], xl, raw[, 3], angle = 90, code = 3,
       length = 0.03, col = "#8A8883")
points(xl, raw[, 1], pch = pchs, bg = "white", col = "#5B5A56",
       cex = 1.2)
arrows(xr, adj[, 2], xr, adj[, 3], angle = 90, code = 3,
       length = 0.03, col = okabe)
points(xr, adj[, 1], pch = pchs, bg = okabe, col = "#1A1A1A", cex = 1.2)
legend("topleft",
       c("Unadjusted", sprintf("Adjusted (pre = %.1f)", mean(k$pre))),
       pch = c(21, 21), pt.bg = c("white", "#5B5A56"),
       col = c("#5B5A56", "#1A1A1A"), bty = "n")
dev.off()

# ============================================================
# 第 2 题  60 例脑卒中患者的重复测量方差分析
# ============================================================
s <- read.csv("data/stroke.csv", fileEncoding = "UTF-8")
s$group <- factor(s$group, levels = c("新型训练组", "常规训练组"))
str(s)
Y <- as.matrix(s[, c("baseline", "y_wk4", "y_wk8")])
g <- as.integer(s$group)                          # 1 = 新型，2 = 常规

# 基线可比性
t.test(age ~ group, data = s, var.equal = TRUE)
t.test(baseline ~ group, data = s, var.equal = TRUE)

# 宽型转长型
L <- pivot_longer(s, cols = c(baseline, y_wk4, y_wk8),
                  names_to = "time", values_to = "y")
L$time <- factor(L$time, levels = c("baseline", "y_wk4", "y_wk8"),
                 labels = c("T0", "T4", "T8"))

# ---------- 第一步：描述与画图 ----------
aggregate(y ~ group + time, data = L, FUN = desc)

cols2 <- okabe[1:2]
wk <- c(0, 4, 8)
pdf("output/hw4/fig2_profile.pdf", width = 7.2, height = 3.2,
    useDingbats = FALSE)
layout(matrix(1:3, 1), widths = c(1.25, 1, 1))
par(mar = c(4.2, 4.2, 2, 0.8), mgp = c(2.4, 0.7, 0), cex = 0.82,
    las = 1)
mm <- sapply(1:3, function(j) tapply(Y[, j], g, mean))
ci <- sapply(1:3, function(j) tapply(Y[, j], g, function(x)
  qt(0.975, length(x) - 1) * sd(x) / sqrt(length(x))))
plot(NA, xlim = c(-0.8, 8.8), ylim = c(40, 70), xaxt = "n",
     xlab = "Week", ylab = "Upper-limb function score",
     main = "(a) Group means, 95% CI", font.main = 1, cex.main = 1)
axis(1, at = wk)
for (i in 1:2) {
  x <- wk + c(-0.2, 0.2)[i]
  arrows(x, mm[i, ] - ci[i, ], x, mm[i, ] + ci[i, ], angle = 90,
         code = 3, length = 0.03, col = cols2[i])
  lines(x, mm[i, ], col = cols2[i], lwd = 2.2, lty = c(1, 2)[i])
  points(x, mm[i, ], pch = c(21, 24)[i], bg = cols2[i],
         col = "#1A1A1A", cex = 1.1)
}
legend("topleft", c("New training", "Conventional"), col = cols2,
       pt.bg = cols2, pch = c(21, 24), lty = c(1, 2), lwd = 2.2,
       bty = "n")
for (i in 1:2) {
  plot(NA, xlim = c(-0.5, 8.5), ylim = range(Y), xaxt = "n",
       xlab = "Week", ylab = "",
       main = c("(b) New training", "(c) Conventional")[i],
       font.main = 1, cex.main = 1)
  axis(1, at = wk)
  for (j in which(g == i))
    lines(wk, Y[j, ], col = adjustcolor("#5B5A56", 0.35))
  lines(wk, mm[i, ], col = cols2[i], lwd = 2.6, lty = c(1, 2)[i])
  points(wk, mm[i, ], pch = c(21, 24)[i], bg = cols2[i],
         col = "#1A1A1A", cex = 1.1)
}
dev.off()

# ---------- 第二步：球形检验 ----------
mod <- aov_ez(id = "id", dv = "y", data = L,
              within = "time", between = "group", type = 3)
summary(mod)                      # 含 Mauchly 检验、GG 与 HF 校正

# 合并组内协方差阵与差值方差
S1 <- cov(Y[g == 1, ]); S2 <- cov(Y[g == 2, ])
Sp <- (29 * S1 + 29 * S2) / 58
round(S1, 1); round(S2, 1); round(Sp, 2)
D <- cbind(d12 = Y[, 1] - Y[, 2], d13 = Y[, 1] - Y[, 3],
           d23 = Y[, 2] - Y[, 3])
round(diag((29 * cov(D[g == 1, ]) + 29 * cov(D[g == 2, ])) / 58), 2)

# Mauchly W 与 GG 系数（正交对比）
C <- rbind(c(1, -1, 0) / sqrt(2),
           c(1, 1, -2) / sqrt(6))
Sc <- C %*% Sp %*% t(C); p <- nrow(C); nu <- 58
W <- det(Sc) / (sum(diag(Sc)) / p)^p
chi <- -(nu - (2 * p^2 + p + 2) / (6 * p)) * log(W)
c(W = W, chi = chi,
  P = pchisq(chi, p * (p + 1) / 2 - 1, lower.tail = FALSE))
lam <- eigen(Sc)$values
sum(lam)^2 / (p * sum(lam^2))                     # GG epsilon

# 两组协方差阵是否相同（Box's M）与各时点方差齐性
boxM <- function(Y, g) {
  ni <- as.vector(table(g)); q <- ncol(Y); m <- length(ni)
  Si <- lapply(sort(unique(g)), function(l) cov(Y[g == l, ]))
  Sp <- Reduce(`+`, Map(function(S, n) (n - 1) * S, Si, ni)) /
    (sum(ni) - m)
  ld <- sapply(Si, function(S) log(det(S)))
  M  <- (sum(ni) - m) * log(det(Sp)) - sum((ni - 1) * ld)
  c1 <- (sum(1 / (ni - 1)) - 1 / (sum(ni) - m)) *
    (2 * q^2 + 3 * q - 1) / (6 * (q + 1) * (m - 1))
  chi <- M * (1 - c1); df <- q * (q + 1) * (m - 1) / 2
  c(M = M, chi = chi, df = df,
    P = pchisq(chi, df, lower.tail = FALSE))
}
boxM(Y, g)
sapply(1:3, function(j) leveneTest(Y[, j] ~ s$group)[1, "Pr(>F)"])

# ---------- 第三步：三个 F 检验 ----------
anova(mod, correction = "none", es = "pes")
anova(mod, correction = "GG", es = c("pes", "ges"))
anova(mod, correction = "HF")
summary(mod$Anova, multivariate = TRUE)     # 多元检验，不需要球形假设

# 变异分解（手算核对）
n <- 30; N <- 60; K <- 3
gm  <- mean(Y)
mi  <- as.vector(tapply(rowMeans(Y), g, mean))    # 组均数
mk  <- colMeans(Y)                                # 时点均数
mik <- apply(Y, 2, function(x) tapply(x, g, mean))   # 组 x 时点均数
mij <- rowMeans(Y)                                # 个体均数
SS_group <- n * K * sum((mi - gm)^2)
SS_subj  <- K * sum((mij - mi[g])^2)
SS_time  <- N * sum((mk - gm)^2)
SS_int   <- n * sum((mik - outer(mi, rep(1, K)) -
                       outer(rep(1, 2), mk) + gm)^2)
SS_err   <- sum((Y - outer(mij, rep(1, K)) - mik[g, ] + mi[g])^2)
round(c(SS_group, SS_subj, SS_time, SS_int, SS_err,
        sum((Y - gm)^2)), 2)
c(F_group = (SS_group / 1) / (SS_subj / 58),
  F_time  = (SS_time / 2) / (SS_err / 116),
  F_int   = (SS_int / 2) / (SS_err / 116))

# ---------- 第四步：两两比较（简单效应） ----------
emm1 <- emmeans(mod, ~ time | group)              # 组内：固定组别比时点
emm1
pairs(emm1, adjust = "bonferroni")
confint(pairs(emm1, adjust = "bonferroni"))
emm2 <- emmeans(mod, ~ group | time)              # 组间：固定时点比组别
pairs(emm2)
confint(pairs(emm2))
summary(pairs(emm2), by = NULL, adjust = "bonferroni")   # 合并校正

# 两组差距在各阶段的变化（交互对比）
ic <- contrast(emmeans(mod, ~ time * group),
               interaction = c("consec", "pairwise"))
ic; confint(ic)
# 8 周总改善的组间比较
t.test(I(y_wk8 - baseline) ~ group, data = s, var.equal = TRUE)
