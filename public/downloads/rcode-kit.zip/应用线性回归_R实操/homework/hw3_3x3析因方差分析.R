# 应用线性回归 课后作业（三）
# 数据：data/sbp_factorial3x3.csv（即 hw3/data.csv，在学习包根目录运行）
# 图形输出到 output/hw3

library(car)

okabe <- c("#0072B2", "#D55E00", "#009E73")
dir.create("output/hw3", recursive = TRUE, showWarnings = FALSE)

# 效应编码（sum-to-zero），与模型中的约束条件一致
options(contrasts = c("contr.sum", "contr.poly"))

# ==================== 读入数据 ====================
d <- read.csv("data/sbp_factorial3x3.csv", check.names = FALSE,
              fileEncoding = "UTF-8")
names(d) <- c("id", "A", "B", "y")
d$A <- factor(substr(d$A, 1, 2))     # A1/A2/A3 = 10/20/30 mg
d$B <- factor(substr(d$B, 1, 2))     # B1/B2/B3 = 2.5/5/10 mg
str(d)
table(d$A, d$B)                      # 每组 6 人，平衡设计

# 核对表 1
cm <- tapply(d$y, list(d$A, d$B), mean)
cs <- tapply(d$y, list(d$A, d$B), sd)
round(cm, 3); round(cs, 3)

# ==================== 第 1 题 设计与模型 ====================
m <- lm(y ~ A * B, data = d)         # 等价于 aov(y ~ A * B)
summary(m)
ncol(model.matrix(m))                # 1 + 2 + 2 + 4 = 9 个参数
mse <- deviance(m) / df.residual(m)

# 基本假定的检查
leveneTest(y ~ A * B, data = d)                  # 方差齐性（中位数中心）
bartlett.test(y ~ interaction(A, B), data = d)
max(cs) / min(cs)                                # 最大与最小标准差之比
shapiro.test(resid(m))                           # 残差正态性
outlierTest(m)                                   # 28 号
d[28, ]

# 去掉 28 号的敏感性分析（不平衡，用 II 型平方和）
m28 <- lm(y ~ A * B, data = d[-28, ])
Anova(m28, type = 2)
shapiro.test(resid(m28))
round(tapply(d$y[-28], list(d$A[-28], d$B[-28]), sd), 3)

# 残差图
pdf("output/hw3/fig1_residuals.pdf", width = 7.2, height = 3.4, useDingbats = FALSE)
par(mfrow = c(1, 2), mar = c(4.2, 4.2, 2, 1), mgp = c(2.4, 0.7, 0),
    cex = 0.82, las = 1)
grp <- interaction(d$A, d$B, sep = "")
grp <- factor(grp, levels = paste0(rep(c("A1", "A2", "A3"), each = 3),
                                   rep(c("B1", "B2", "B3"), 3)))
r <- resid(m)
set.seed(1); gx <- jitter(as.numeric(grp), 0.5)
plot(gx, r, pch = 19, col = "#5B5A56", xlim = c(0.6, 9.4),
     xaxt = "n", xlab = "Treatment group", ylab = "Residual (mmHg)",
     main = "(a) Residuals by group", font.main = 1, cex.main = 1)
axis(1, at = 1:9, labels = levels(grp), cex.axis = 0.68, gap.axis = 0)
abline(h = 0, col = "#C9C7C1")
points(gx[28], r[28], pch = 19, col = okabe[2])
text(gx[28], r[28], "28", pos = 4, cex = 0.85, col = okabe[2])
qq <- qqnorm(rstudent(m), plot.it = FALSE)
plot(qq, pch = 19, col = "#5B5A56", xlab = "Theoretical quantiles",
     ylab = "Studentized residual", main = "(b) Normal Q-Q",
     font.main = 1, cex.main = 1)
qqline(rstudent(m), col = okabe[1], lwd = 1.6)
points(qq$x[28], qq$y[28], pch = 21, bg = okabe[2], col = okabe[2])
text(qq$x[28], qq$y[28], "28", pos = 4, cex = 0.85, col = okabe[2])
dev.off()

# ==================== 第 2 题 方差分析表 ====================
a <- anova(m)                        # 平衡设计，I、II、III 型平方和相同
a
Anova(m, type = 3)
sum(a$`Sum Sq`)                      # 总平方和
sum((d$y - mean(d$y))^2)
qf(0.95, 2, 45); qf(0.95, 4, 45)     # F 临界值

# 由表 1 的均数和标准差手算
gm <- mean(cm); am <- rowMeans(cm); bm <- colMeans(cm)
n <- 6; a.lev <- 3; b.lev <- 3
SSA    <- b.lev * n * sum((am - gm)^2)
SSB    <- a.lev * n * sum((bm - gm)^2)
SScell <- n * sum((cm - gm)^2)
SSAB   <- SScell - SSA - SSB
SSE    <- (n - 1) * sum(cs^2)
round(c(SSA = SSA, SSB = SSB, SSAB = SSAB, SSE = SSE, SST = SScell + SSE), 2)

# 效应量
ss <- a$`Sum Sq`
round(ss / sum(ss), 3)                           # eta^2
round(ss[1:3] / (ss[1:3] + ss[4]), 3)            # 偏 eta^2

# ==================== 第 3 题 主效应 ====================
round(am, 3); round(bm, 3); gm
sqrt(mse / 18)                       # 边际均数的标准误
TukeyHSD(aov(y ~ A * B, data = d), c("A", "B"))

# 剂量趋势：A 的三个剂量等距；B 按 log2 剂量等距（2.5、5、10 mg）
contr1 <- function(w) {              # w 为 3x3 单元格均数的对比系数
  L <- sum(w * cm); SS <- n * L^2 / sum(w^2)
  c(L = L, SE = sqrt(mse * sum(w^2) / n), SS = SS, F = SS / mse,
    P = pf(SS / mse, 1, 45, lower.tail = FALSE))
}
lin <- c(-1, 0, 1); quad <- c(1, -2, 1); one <- rep(1, 3)
round(rbind(A.lin  = contr1(outer(lin, one) / 3),
            A.quad = contr1(outer(quad, one) / 3),
            B.lin  = contr1(outer(one, lin) / 3),
            B.quad = contr1(outer(one, quad) / 3)), 4)

# ==================== 第 4 题 交互作用 ====================
# 交互效应 (alpha beta)_ij 与加性模型的预测值
ab <- cm - outer(am, one) - outer(one, bm) + gm
round(ab, 2)
round(outer(am, one) + outer(one, bm) - gm, 2)

# 单元格内的剂量增量
round(cm[, "B3"] - cm[, "B1"], 2)    # 各 A 水平下 B3 - B1
round(cm["A3", ] - cm["A1", ], 2)    # 各 B 水平下 A3 - A1

# 交互作用的 4 个自由度分解
ix <- rbind(LxL = contr1(outer(lin, lin)),
            LxQ = contr1(outer(lin, quad)),
            QxL = contr1(outer(quad, lin)),
            QxQ = contr1(outer(quad, quad)))
round(ix, 4)
ix["LxL", "SS"] / a["A:B", "Sum Sq"]               # 线性 x 线性所占比例
rest <- a["A:B", "Sum Sq"] - ix["LxL", "SS"]
pf(rest / 3 / mse, 3, 45, lower.tail = FALSE)      # 其余 3 个自由度
ix["LxL", "L"] + c(-1, 1) * qt(0.975, 45) * ix["LxL", "SE"]

# 单独效应（用全模型的 MSE，df = 2, 45）
simple <- function(f, g) t(sapply(levels(d[[g]]), function(k) {
  s <- d[d[[g]] == k, ]
  SS <- n * sum((tapply(s$y, s[[f]], mean) - mean(s$y))^2)
  c(SS = SS, F = SS / 2 / mse, P = pf(SS / 2 / mse, 2, 45, lower.tail = FALSE))
}))
round(simple("B", "A"), 4)           # 各 A 水平下 B 的效应
round(simple("A", "B"), 4)           # 各 B 水平下 A 的效应

# 交互作用图
se <- sqrt(mse / n)
pdf("output/hw3/fig2_interaction.pdf", width = 7.2, height = 3.4, useDingbats = FALSE)
par(mfrow = c(1, 2), mar = c(4.2, 4.2, 2, 1), mgp = c(2.4, 0.7, 0),
    cex = 0.82, las = 1)
xb <- log2(c(2.5, 5, 10))
plot(NA, xlim = range(xb) + c(-0.15, 0.15), ylim = c(0, 30), xaxt = "n",
     xlab = "Drug B dose (mg, log scale)", ylab = "SBP reduction (mmHg)",
     main = "(a) Lines for drug A dose", font.main = 1, cex.main = 1)
axis(1, at = xb, labels = c("2.5", "5", "10"))
vir3 <- c("#CAE11F", "#228D8D", "#471365")   # viridis，浅 = 低剂量
for (i in 1:3) {
  arrows(xb, cm[i, ] - se, xb, cm[i, ] + se, angle = 90, code = 3,
         length = 0.03, col = "#5B5A56")
  lines(xb, cm[i, ], col = vir3[i], lwd = 2.2, lty = c(1, 2, 1)[i])
  points(xb, cm[i, ], pch = c(21, 24, 22)[i], bg = vir3[i], col = "#1A1A1A", cex = 1.1)
}
legend("topleft", paste("A", c(10, 20, 30), "mg"), col = vir3, lty = c(1, 2, 1),
       pch = c(21, 24, 22), pt.bg = vir3, lwd = 2.2, bty = "n")
xa <- c(10, 20, 30)
plot(NA, xlim = c(8, 32), ylim = c(0, 30), xaxt = "n",
     xlab = "Drug A dose (mg)", ylab = "SBP reduction (mmHg)",
     main = "(b) Lines for drug B dose", font.main = 1, cex.main = 1)
axis(1, at = xa)
gray3 <- c("#AFADA7", "#6E6C67", "#1A1A1A")   # 灰度，浅 = 低剂量
for (j in 1:3) {
  arrows(xa, cm[, j] - se, xa, cm[, j] + se, angle = 90, code = 3,
         length = 0.03, col = "#5B5A56")
  lines(xa, cm[, j], col = gray3[j], lwd = 2.2, lty = c(1, 2, 1)[j])
  points(xa, cm[, j], pch = c(21, 24, 22)[j], bg = gray3[j], col = "#1A1A1A", cex = 1.1)
}
legend("topleft", paste("B", c(2.5, 5, 10), "mg"), col = gray3, lty = c(1, 2, 1),
       pch = c(21, 24, 22), pt.bg = gray3, lwd = 2.2, bty = "n")
dev.off()
