# 应用线性回归 课后作业（二）
# 数据：data/diabetes27_hw.csv、data/datasetB.csv（在学习包根目录运行）
# 图形输出到 output/hw2

library(car)
library(MASS)

okabe <- c("#0072B2", "#D55E00", "#009E73")
dir.create("output/hw2", recursive = TRUE, showWarnings = FALSE)


# ==================== 第一题 全模型的回归诊断 ====================
d1 <- read.csv("data/diabetes27_hw.csv")
m <- lm(glucose ~ tc + tg + insulin + hba1c, data = d1)
summary(m)
n <- nrow(d1); p <- 4


# ---------- 1. LINE 四条件 ----------
palette(c("black", okabe[2], "#5B5A56"))     # Cook 等高线用橙红色
pdf("output/hw2/fig1_diagnostics.pdf", width = 7.2, height = 6.2, useDingbats = FALSE)
par(mfrow = c(2, 2), mar = c(4.2, 4.2, 2.2, 1), mgp = c(2.4, 0.7, 0),
    cex = 0.82, las = 1)
plot(m, labels.id = d1$id, sub.caption = "", col = "#5B5A56", pch = 19,
     col.smooth = okabe[1], lwd = 1.6, cex.id = 0.9)
dev.off()
palette("default")

shapiro.test(resid(m))              # N
ncvTest(m)                          # E
set.seed(2026)
durbinWatsonTest(m, reps = 5000)    # I，行序无实际含义，结果仅作参考

# L：三项指定检验都不针对线性，补 Tukey 检验和 hba1c 二次项
residualPlots(m, plot = FALSE)
m.q <- update(m, . ~ . + I(hba1c^2))
anova(m, m.q)
summary(m.q)$adj.r.squared
coef(summary(m.q))["tc", ]
residualPlots(update(m, data = d1[d1$id != 25, ]), plot = FALSE)
anova(update(m, data = d1[d1$id != 25, ]), update(m.q, data = d1[d1$id != 25, ]))


# ---------- 2. 共线性 ----------
x1 <- c("tc", "tg", "insulin", "hba1c")
round(cor(d1[, x1]), 3)
round(vif(m), 3)
ev <- eigen(cor(d1[, x1]))$values
sqrt(max(ev) / min(ev))             # 条件数

# tc 系数：简单回归 vs 全模型
s1 <- lm(glucose ~ tc, data = d1)
coef(summary(s1))["tc", ]
coef(summary(m))["tc", ]
sigma(s1); sigma(m)
coef(s1)["tc"] / coef(summary(m))["tc", "Std. Error"]   # 只有 SE 变化时的 t 值

# tc 与 glucose 的偏相关
cor(resid(lm(glucose ~ tg + insulin + hba1c, d1)),
    resid(lm(tc ~ tg + insulin + hba1c, d1)))

# 去掉 25 号后
coef(summary(lm(glucose ~ tc, d1[d1$id != 25, ])))["tc", ]
cor(d1$tc[d1$id != 25], d1$tg[d1$id != 25])
round(vif(update(m, data = d1[d1$id != 25, ])), 3)


# ---------- 3. 强影响点 ----------
inf <- data.frame(d1[, c("id", x1, "glucose")], h = hatvalues(m),
                  r = rstudent(m), D = cooks.distance(m))
round(inf[order(-inf$D)[1:5], ], 3)
round(inf[order(-abs(inf$r))[1:3], ], 3)
c(h = 2 * (p + 1) / n, D = 4 / (n - p - 1))
outlierTest(m)                      # Bonferroni 校正


# ---------- 4. 删除前后对照 ----------
k <- which.max(cooks.distance(m))
m.del <- update(m, data = d1[-k, ])
round(cbind(before = coef(m), after = coef(m.del),
            P.before = coef(summary(m))[, 4], P.after = coef(summary(m.del))[, 4]), 3)
round(c(summary(m)$r.squared, summary(m.del)$r.squared), 3)
round(confint(m.del), 3)


# ---------- 思考 ----------
sort(d1$tg, decreasing = TRUE)[1:2]
sort(d1$tc, decreasing = TRUE)[1:2]
m.mm <- rlm(glucose ~ tc + tg + insulin + hba1c, data = d1, method = "MM")
round(coef(m.mm), 3)
round(m.mm$w[k], 2)                 # 25 号在稳健回归中的权重


# ==================== 第二题 datasetB 岭回归 ====================
d2 <- read.csv("data/datasetB.csv")
ols <- lm(glu ~ age + bmi + waist, data = d2)
summary(ols)
N <- nrow(d2); P <- 3


# ---------- 1. 共线性 ----------
x2 <- c("age", "bmi", "waist")
round(cor(d2[, c(x2, "glu")]), 3)
round(vif(ols), 2)
ev <- eigen(cor(d2[, x2]))$values
sqrt(max(ev) / min(ev))
coef(summary(lm(glu ~ age + bmi, d2)))["bmi", ]
coef(summary(lm(glu ~ age + waist, d2)))["waist", ]


# ---------- 2. 强影响点 ----------
inf2 <- data.frame(d2[, c("id", x2, "glu")], h = hatvalues(ols),
                   r = rstudent(ols), D = cooks.distance(ols))
round(inf2[order(-inf2$D)[1:4], ], 3)
c(h = 2 * (P + 1) / N, D = 4 / (N - P - 1))

# 149 号相对 BMI-腰围直线的位置
wb <- lm(waist ~ bmi, d2[-149, ])
d2$waist[149] - predict(wb, d2[149, ])   # 高出多少 cm
sigma(wb)
rstudent(lm(waist ~ bmi, d2))[149]
# 149 号在各主成分上的得分（以标准差为单位）
pc <- prcomp(d2[, x2], scale. = TRUE)
round(pc$x[149, ] / pc$sdev, 2)


# ---------- 3. 四种样本下的岭迹 ----------
sets <- list("All 150"            = 1:N,
             "Delete #149"        = setdiff(1:N, 149),
             "Delete #150"        = setdiff(1:N, 150),
             "Delete #149 & #150" = setdiff(1:N, c(149, 150)))
lam <- seq(0, 100, 0.5)
rd <- lapply(sets, function(i)
  lm.ridge(glu ~ age + bmi + waist, d2[i, ], lambda = lam))

# rd$coef：自变量标准化、因变量不变；coef(rd)：还原到原始尺度
scaled <- lapply(rd, function(r) t(r$coef))

# GCV 最小的 lambda
sapply(rd, function(r) r$lambda[which.min(r$GCV)])
round(rd[[1]]$GCV[lam %in% c(0, 7.5, 30)], 6)

# 准则一：bmi、waist 都为正的最小 lambda
first.pos <- sapply(scaled, function(b) lam[which(b[, "waist"] > 0 & b[, "bmi"] > 0)[1]])
first.pos

# 准则二：lambda 增 10 时 bmi、waist 的系数变化都不超过 0.01
first.stable <- sapply(scaled, function(b) {
  s <- 20                                # 步长 0.5，20 格 = 10
  dif <- abs(b[-(1:s), 2:3] - b[1:(nrow(b) - s), 2:3])
  lam[which(apply(dif, 1, max) <= 0.01)[1]]
})
first.stable
round(abs(scaled[[4]][lam == 40, 2:3] - scaled[[4]][lam == 30, 2:3]), 4)  # 删两人时 30→40

# 候选 lambda 对比
cand <- c(0, 7.5, 20, 30, 60)
r2 <- function(b, dat) {                 # b 为原始尺度系数
  e <- dat$glu - drop(cbind(1, as.matrix(dat[, x2])) %*% b)
  1 - sum(e^2) / sum((dat$glu - mean(dat$glu))^2)
}
tab <- sapply(cand, function(l) {
  j <- which(lam == l)
  c(scaled[[1]][j, ], waist.del149 = scaled[[2]][j, "waist"],
    sum.bw = sum(scaled[[1]][j, 2:3]),
    R2 = r2(coef(rd[[1]])[j, ], d2),
    age.shrink = 1 - scaled[[1]][j, "age"] / scaled[[1]][1, "age"])
})
colnames(tab) <- cand
round(tab, 4)

# 岭迹图
pdf("output/hw2/fig2_ridge_trace.pdf", width = 7.2, height = 5.8, useDingbats = FALSE)
par(mfrow = c(2, 2), mar = c(4.2, 4.2, 2.2, 1), mgp = c(2.4, 0.7, 0),
    cex = 0.82, las = 1)
for (s in seq_along(rd)) {
  b <- scaled[[s]]
  matplot(lam, b, type = "n", ylim = c(-0.3, 0.5), xlab = expression(lambda),
          ylab = "Coefficient (X standardized)",
          main = paste0("(", letters[s], ") ", names(rd)[s]),
          font.main = 1, cex.main = 1)
  abline(h = 0, col = "#C9C7C1")
  abline(v = 30, col = "#5B5A56", lty = 3)
  text(30, 0.47, expression(lambda == 30), pos = 4, cex = 0.8, col = "#5B5A56")
  matlines(lam, b, lty = c(1, 2, 4), lwd = 1.8, col = okabe)
  x0 <- first.pos[s]
  points(x0, 0, pch = 21, bg = "white", col = okabe[3], lwd = 1.3)
  text(x0, 0, bquote(lambda == .(x0)), pos = 1, cex = 0.8, col = okabe[3])
  if (s == 1) legend("bottomright", c("age", "bmi", "waist"), lty = c(1, 2, 4), lwd = 1.8,
                     col = okabe, bty = "n", cex = 0.9)
}
dev.off()


# ---------- 4. 回归方程与敏感性分析 ----------
L <- 30
final <- coef(lm.ridge(glu ~ age + bmi + waist, d2, lambda = L))
round(final, 4)

# 按定义手算核对
X <- scale(as.matrix(d2[, x2]), center = TRUE, scale = FALSE)
sc <- sqrt(colSums(X^2) / N)
Z <- sweep(X, 2, sc, "/")
b.std <- solve(crossprod(Z) + L * diag(P), crossprod(Z, d2$glu - mean(d2$glu)))
b.raw <- drop(b.std) / sc
stopifnot(all.equal(unname(c(mean(d2$glu) - sum(b.raw * colMeans(d2[, x2])), b.raw)),
                    unname(final), tolerance = 1e-8))

# 四种样本的 OLS 与岭回归（lambda = 30）
sens <- t(sapply(sets, function(i) {
  o <- lm(glu ~ age + bmi + waist, d2[i, ])
  r <- coef(lm.ridge(glu ~ age + bmi + waist, d2[i, ], lambda = L))
  c(coef(o), R2.ols = summary(o)$r.squared, r, R2.ridge = r2(r, d2[i, ]))
}))
round(sens, 4)
# bmi + waist 的合计效应（每 1 个标准差），OLS 与 lambda = 30
sapply(scaled, function(b) round(sum(b[1, 2:3]), 3))
sapply(scaled, function(b) round(sum(b[lam == L, 2:3]), 3))
# 只放一个肥胖指标时的效应，作对照
psd <- function(x) sqrt(mean((x - mean(x))^2))
coef(lm(glu ~ age + bmi, d2))["bmi"] * psd(d2$bmi)
coef(lm(glu ~ age + waist, d2))["waist"] * psd(d2$waist)

# 岭回归下的杠杆值与影响度量；lambda = 0 时 D 就是 Cook 距离
ridge.inf <- function(l) {
  H <- Z %*% solve(crossprod(Z) + l * diag(P), t(Z)) + 1 / N
  e <- d2$glu - drop(H %*% d2$glu)
  df <- sum(diag(H)); s2 <- sum(e^2) / (N - df)
  Xc <- cbind(1, as.matrix(d2[, x2]))
  b0 <- coef(lm.ridge(glu ~ age + bmi + waist, d2, lambda = l))
  D <- sapply(1:N, function(i) {
    bi <- coef(lm.ridge(glu ~ age + bmi + waist, d2[-i, ], lambda = l))
    sum((Xc %*% (bi - b0))^2) / (df * s2)
  })
  list(df = df, s = sqrt(s2), h = diag(H), D = D,
       loocv = mean((e / (1 - diag(H)))^2))
}
inf0 <- ridge.inf(0); inf30 <- ridge.inf(L)
stopifnot(all.equal(unname(inf0$D), unname(cooks.distance(ols))))
round(c(inf0$h[149], inf30$h[149], inf0$h[150], inf30$h[150]), 3)
round(c(inf0$D[149], inf30$D[149], inf0$D[150], inf30$D[150]), 3)
order(-inf30$D)[1:3]
round(c(df = inf30$df, s = inf30$s, loocv.ols = inf0$loocv, loocv.ridge = inf30$loocv), 4)

# 删除 149 号前后，其余 149 人预测值的最大差异
Xc <- cbind(1, as.matrix(d2[, x2]))
pred.gap <- function(del, l) {
  b1 <- coef(lm.ridge(glu ~ age + bmi + waist, d2, lambda = l))
  b2 <- coef(lm.ridge(glu ~ age + bmi + waist, d2[-del, ], lambda = l))
  max(abs(Xc[-del, ] %*% (b1 - b2)))
}
round(c(ols = pred.gap(149, 0), ridge = pred.gap(149, L)), 3)

# 岭回归不改变方差不齐
ncvTest(ols)
