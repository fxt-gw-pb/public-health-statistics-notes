read.csv("d://data/bp.csv")->da

#将100名高血压患者随机分为两组，给予A,B两种药物治疗，疗前及疗后8周测SBP

# 描述统计
aggregate(cbind(base, post) ~ group, data = bp, FUN = mean)
# 方案A：base ≈ 158，post ≈ 137，降幅 ≈ 21
# 方案B：base ≈ 142，post ≈ 131，降幅 ≈ 11

# 不做校正，直接比较用药后均值（错误做法）
t.test(post ~ group, data = bp)
# 结论：方案A 用药后均值反而更高（136 vs 132），若只看这一步会误以为方案A 更差​​# 第二步：斜率同质性检验

fit_full <- lm(post ~ group * base, data = bp)
anova(fit_full)

# 交互项不显著则平行性成立，可继续做协方差分析
# 校正模型
fit <- lm(post ~ group + base, data = bp)
summary(fit)
anova(fit)

library(emmeans)
emm <- emmeans(fit, ~ group)
print(emm, adjust = "bonferroni")
pairs(emm, adjust = "bonferroni")
# 校正后方案A 的均值应低于方案B，与直接比较的结论相反

#读入宽型数据dm
read.csv("d://data/dm.csv")->dm

#转为长型数据df_long
df_long <- pivot_longer(dm, cols = c(hba1c_0, hba1c_3, hba1c_6),
                        names_to = "time", values_to = "hba1c")
df_long$time  <- factor(df_long$time, levels = c("hba1c_0","hba1c_3","hba1c_6"))
df_long$group <- factor(df_long$group)
names(df_long)[1] <- "patient_id"

#单组重复测量资料方差分析用到A组资料
da <- df_long[df_long$group=="A药组",]

#描述各时点均值
aggregate(hba1c ~ group + time, data = da,
          FUN = function(x) c(mean = round(mean(x),2), sd = round(sd(x),2)))

#单组重复测量资料方差分析
library(afex)
sub <- subset(df_long, group == "A药组")
mod1 <- aov_ez(id = "patient_id", dv = "hba1c", data = sub, within = "time")
summary(mod1)

#考察球形假设是否成立
cov(dm[1:20,4:6])

# 转成差值
d12 <- dm[1:20, 4] - dm[1:20, 5]
d13 <- dm[1:20, 4] - dm[1:20, 6]
d23 <- dm[1:20, 5] - dm[1:20, 6]
S<-cov(cbind(d12, d13, d23));S

A <- rbind(c(1, -1,  0),
           c(1,  1, -2))

# 手动逐行标准化
C <- A
for (i in 1:nrow(A)) {
  C[i, ] <- A[i, ] / sqrt(sum(A[i, ]^2))
}
print(C)

Y <- as.matrix(dm[1:20, 4:6])
S <- cov(Y %*% t(C))
W <- det(S) / (sum(diag(S))/2)^2
W

#单组重复测量资料方差分析的变异分解过程
c(dm[1:20,4],dm[1:20,5],dm[1:20,6])->y
da<-matrix(y,20,3)
m<-mean(y)
mi<-apply(da,1,mean)
mj<-apply(da,2,mean)
SST<-var(y)*59
SS_time <- sum((mj-m)^2*20) 
SS_subject <- sum((mi-m)^2*3)
SS_error <- SST-SS_time-SS_subject
F_time<-(SS_time/2)/(SS_error/38)

#多组重复测量资料方差分析用到AB两组资料

read.csv("d://data/df_long.csv")->df_long

#多组重复测量资料方差分析
library(afex)
mod <- aov_ez(id = "patient_id", dv = "hba1c", data = df_long,
              within = "time", between = "group")
summary(mod)

#多组重复测量资料方差分析的变异分解过程
c(dm[,4],dm[,5],dm[,6])->y
da<-matrix(y,40,3)
da1<-da[1:20,]
da2<-da[21:40,]
m<-mean(y)
mi<-c(mean(da1),mean(da2))
mij<-c(apply(da1,1,mean),apply(da2,1,mean))
mil<-c(apply(da1,2,mean),apply(da2,2,mean))
ml<-apply(da,2,mean)

SST<-var(y)*119
SS_group<- sum((mi-m)^2*60)
SS_time <- sum((ml-m)^2*40) 
SS_交互 <- sum(((mil - rep(mi,c(3,3)) - rep(ml,2) + m))^2*20) 

gid <- rep(1:2, each = 20)
SS_受试者间 <- 3 * sum((mij - mi[gid])^2)
SS_受试者内 <- SST-(SS_group + SS_time + SS_交互 +  SS_受试者间)
SS_受试者内 <-sum((c(t(da)) - rep(mij,rep(3,40)) - c(rep(mil[1:3],20),rep(mil[4:6],20)) + rep(mi,c(60,60)))^2) 

F_交互<-(SS_交互/(1*2))/(SS_受试者内/(38*2))

#交互有统计学意义后作简单效应分析
library(emmeans)
emm <- emmeans(mod, ~ time | group)
pairs(emm, adjust = "bonferroni")