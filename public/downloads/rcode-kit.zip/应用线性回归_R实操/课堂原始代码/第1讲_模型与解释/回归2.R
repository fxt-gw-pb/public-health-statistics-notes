#读取数据
read.csv("d://data/a.csv",header=T)[,-1]->d
d$age->x1

#了解年龄分布
hist(x1)
quantile(x1)

d$bmi->x2
d$glu->y

#讨论变量间相关性
cor(d)

#散点图(单个自变量和Y)
plot(x1,y)
plot(x2,y)

#简单线性回归
out<-lm(y~x2)
summary(out)

#引入年龄分组变量
breaks<-c(29,45,58,80)
group<-factor(cut(x1,breaks,right=T))
table(group)

#不同年龄组内做简单线性回归
x2a <- x2[group=="(29,45]"]
ya <- y[group=="(29,45]"]

x2b <- x2[group=="(45,58]"]
yb <- y[group=="(45,58]"]

x2c<- x2[group=="(58,80]"]
yc <- y[group=="(58,80]"]

lm(ya~x2a)
lm(yb~x2b)
lm(yc~x2c)

#作图
plot(x2,y)
lines(x2,predict(lm(y~x2)),lty=2)
lines(x2a,predict(lm(ya~x2a)),col="blue")
lines(x2b,predict(lm(yb~x2b)),col="green")
lines(x2c,predict(lm(yc~x2c)),col="purple")

#斜率比较
lm(ya~x2a)$coefficients
lm(yb~x2b)$coefficients
lm(yc~x2c)$coefficients
lm(y~x2)$coefficients

#多重线性回归
lm(y~group+x2)
lm(y~x1+x2)

#回归系数的95%区间估计
confint(lm(y~x2))
confint(lm(y~x1+x2))

#回归系数的矩阵解
X<-cbind(1,x1,x2)
b<-solve(t(X)%*%X)%*%t(X)%*%y
yhat <- X%*%b
H<-X%*%solve(t(X)%*%X)%*%t(X)

#残差及最小的残差平方和
e<-y-yhat
t(e)%*%e

#最大似然法估计回归系数的话使lnL最大
n<-200
(-n/2*log(2*pi)-n/2*log(t(e)%*%e/n)-(t(e)%*%e)/(2*(t(e)%*%e/n)))
(-n/2*log(2*pi)-n/2*log(t(e)%*%e/n)-n/2)

#而仅x2的模型lnL会变小
e<-resid(lm(y~x2))
n<-200
(-n/2*log(2*pi)-n/2*log(t(e)%*%e/n)-n/2)

leverage <- diag(H)
mean(leverage);(2+1)/200
range(leverage)

#no51疑是x的离群点
which(leverage==max(leverage))

#方差分析观察平方和的分解过程
anova(lm(y~x2))
anova(lm(y~x1+x2))
anova(lm(y~group+x2))

#t检验
summary(lm(y~x1+x2))

#回归系数标准误的估计--以x2为例
X<-cbind(1,x1,x2)
solve(t(X)%*%X)*0.5393^2

0.0001432228^0.5

#拟合优度评价
out<-lm(y~x1+x2)
step(out)
AIC(out)


#偏相关系数
library(ppcor)
pcor(d)
pcor.test(x2,y,x1)

#均数或个体值的95%区间估计
new <- data.frame(x1=56,x2=26.8)

new <- data.frame(x1=mean(x1),x2=mean(x2))
new <- data.frame(x1=52,x2=24)
predict(out, new, interval = "confidence")
predict(out, new, interval = "prediction")

#AIC和其简化值得计算过程
resid(out)->e
t(e)%*%e
n<-length(y)
2*4-2*(-200/2*log(2*pi)-200/2*log(t(e)%*%e/200)-(t(e)%*%e)/(2*(t(e)%*%e/200)))
AIC(out)

200*log(t(e)%*%e/200)+2*(2+1)

resid(lm(y~x2))->e
200*log(t(e)%*%e/200)+2*(1+1)

resid(lm(y~x1))->e
200*log(t(e)%*%e/200)+2*(1+1)

