# ============================================================
# 应用线性回归（一）· R 上手
# 全程只用 3 个函数：read.csv()   lm()   summary()
# 配套数据：datasetA.csv（n=200，模拟数据，与本课件同一份）
# 建议：本文件与 datasetA.csv 放在同一个文件夹里
# ============================================================


# ---------- 0. 先把工作目录指到数据所在的文件夹 ----------

getwd()                      # 先看一眼：现在在哪个目录？
# setwd("C:/Users/你的名字/Desktop/regression")   # 不对就改这一行，注意用正斜杠 /
# 更省事的办法：RStudio 里点 Session → Set Working Directory → To Source File Location


# ---------- 1. 读数据：read.csv() ----------

d <- read.csv("datasetA.csv")

head(d)          # 看前 6 行。四列：id / age / bmi / glu
str(d)           # 看每列是什么类型。age、bmi、glu 都应该是 num（数值型）
summary(d)       # 每列的最小值、四分位数、中位数、均值、最大值
                 # 这一步不是走过场：先看数据的量级和范围，能挡掉一半的低级错误

nrow(d)          # 200
# 记住：任何分析之前，先 head / str / summary 三连


# ---------- 2. 画一张图，先看一眼关系 ----------

plot(glu ~ bmi, data = d,
     xlab = "BMI", ylab = "空腹血糖 (mmol/L)",
     main = "BMI 与血糖：一眼看上去是正的")
# 图是课件第 3 页那张。先建立直觉，再上数字


# ---------- 3. 建模型：lm() ----------

# 【模型 1】简单回归：只放 bmi
fit1 <- lm(glu ~ bmi, data = d)

summary(fit1)
# 去 Coefficients 表里找 bmi 那一行：
#   Estimate = 0.106   ← 课件第 3 页的"漂亮结果"
#   Pr(>|t|) 极小       ← P < 1e-13
# 读法：BMI 每高 1，血糖平均高 0.106 mmol/L

# 【模型 2】多重回归：把 age 也放进去
fit2 <- lm(glu ~ age + bmi, data = d)

summary(fit2)
# 再看 bmi 那一行：
#   Estimate 从 0.106 变成了 0.077
# 这就是课件一的核心：_age 一进来，BMI 的系数掉了 27%。
# 原来那个 0.106 里，有一部分是"年纪大的人 BMI 高、血糖也高"造成的，
# 并不都是 BMI 自己的功劳。

# 一句话记住 lm() 的写法：
#   lm(因变量 ~ 自变量1 + 自变量2, data = 数据框)
#   ~ 读作"由……来解释"，+ 表示"同时放进模型"


# ---------- 4. 两个模型并排放着看 ----------

coef(summary(fit1))    # 只要系数表，不要别的
coef(summary(fit2))    # 对照着看：bmi 的 Estimate / Std.Error / t value / Pr 全变了

# 顺手记两个后面要用的东西（本课不展开，第 3 次课会讲）
confint(fit2)          # 系数的 95% 置信区间
anova(fit2)            # 方差分析表


# ---------- 5. 预测：predict() ----------
# 问：一个 52 岁、BMI 24 的人，血糖预计是多少？

newpt <- data.frame(age = 52, bmi = 24)   # 新数据必须做成 data.frame，
                                          # 而且列名要和建模时用的一模一样

predict(fit2, newdata = newpt, interval = "confidence")  # 均数的区间（窄）
predict(fit2, newdata = newpt, interval = "prediction")  # 个体的区间（宽）

# 两个区间相差十几倍——这是课件第 14 页最容易被搞混的一对。
# 常见报错：'newdata' 有 1 行，但找到的变量有 X 行
#   → 十有八九是列名写错了，或者漏了某个自变量。检查 names(newpt) 与 names(d)


# ============================================================
# 课后自己跑（对应第 2–4 次课，课上讲完哪一节就跑到哪一步）
# ============================================================

# --- 第 2 次课之后：分层，看斜率怎么变 ---
d$agegrp <- cut(d$age, breaks = c(29, 45, 58, 79),
                labels = c("30-45", "46-58", "59-78"))
table(d$agegrp)                                   # 56 / 94 / 50 人

# 层内各跑一次简单回归，看三条线的斜率
by(d, d$agegrp, function(x) coef(lm(glu ~ bmi, data = x))[2])
# 三条斜率大概在 0.07–0.10 之间晃，交互检验 P ≈ 0.50
#   → 看着不齐，但那点起伏在抽样误差之内，可以合成一个共斜率

coef(lm(glu ~ bmi + agegrp, data = d))            # 共斜率 ≈ 0.086


# --- 第 3 次课之后：把课件里的数字亲手算一遍 ---
summary(fit2)$sigma          # 残差标准误
summary(fit2)$r.squared      # R²
summary(fit2)$df             # 自由度：n - p - 1 = 200 - 2 - 1 = 197

anova(fit2)                  # 方差分析表：SS 怎么拆、F 怎么来
confint(fit2)                # 系数的 95% CI

# 标准化系数：谁更重要？（课件第 16 页，会出现排序反转）
# 公式：b* = b × SD(x) ÷ SD(y)   ——注意 y 也要除！

b <- coef(fit2)
b[2] * sd(d$age) / sd(d$glu)     # 年龄 0.438
b[3] * sd(d$bmi) / sd(d$glu)     # BMI  0.365
# 原始系数 age 0.030 < bmi 0.077，标准化之后 age 0.438 > bmi 0.365
#   → 原始系数量纲不同，不能直接比大小

# 【易错】下面这种写法是"半标准化"，只除了 x 没除 y，得到的数会小一个 SD(y)：
#   d$zage <- scale(d$age); d$zbmi <- scale(d$bmi)
#   coef(lm(glu ~ zage + zbmi, data = d))     # 得到 0.311 / 0.259，不对
# 要连 y 一起标准化才对：
d$zglu <- scale(d$glu); d$zage <- scale(d$age); d$zbmi <- scale(d$bmi)
coef(lm(zglu ~ zage + zbmi, data = d))       # 0.438 / 0.365，与上面一致


# --- 第 4 次课之后：读输出 + 写报告 ---
summary(fit2)
# 你能不能对着这个输出，说出这四件事：
#   1. bmi 的系数是多少、怎么解释
#   2. 它的 95% CI 是多少
#   3. 整个模型有没有用（看最后一行的 F 检验）
#   4. 模型解释了百分之多少的变异（看 R²）
# 说得出这四条，课件一就过关了。
