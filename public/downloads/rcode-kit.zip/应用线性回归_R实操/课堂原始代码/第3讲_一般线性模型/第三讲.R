read.csv("d://data/datasetB.csv",header=T)[,-5]->da
da[1:4,]

fit<-lm(glu~age+bmi+waist,data=da)
predict(fit)[1]

library(MASS)
birthwt[1,]

da <- birthwt

da$lwt_group <- factor(cut(da$lwt,breaks=c(-Inf,110,Inf),right = T), ordered = FALSE)
var.test(bwt~lwt_group)
t.test(bwt~lwt_group,var.equal = T) #成组t检验与一般线性模型结果等价

da$group <- ifelse (da$lwt >= 110, 2, 1)     #错误标识
lm(da$bwt~da$group)

fit<-lm(bwt~lwt_group,data=da)
summary(fit)

bwt1 <- bwt[lwt_group=="(-Inf,110]"]
bwt2 <- bwt[lwt_group=="(110,Inf]"]
mean(bwt1);mean(bwt2);
mean(bwt2)-mean(bwt1)

# da$lwt_group <- relevel(da$lwt_group,ref = "(110,Inf]")
da$lwt_group <- factor(da$lwt_group, levels = c("(110, Inf]", "(-Inf,110]"))
fit <- lm(bwt ~ lwt_group,data = da)
fit

da$lwt_group <- cut(da$lwt,breaks=c(-Inf,110,130,150,Inf),right = T)
fit<-lm(bwt~lwt_group,data=da)
summary(fit) #说出检验过程包括对截距和模型系数两个检验

#da$lwt_group <- relevel(da$lwt_group,ref = "(150,Inf]")
da$lwt_group <- factor(da$lwt_group, levels = c("(150, Inf]","(-Inf,110]","(110,130]","(130,150]"))
fit<-lm(bwt~lwt_group,data=da)
summary(fit)  #说出检验过程，若模型系数里有P>0.05的可以删除吗

#模型比较
AIC(lm(bwt~lwt))
da$lwt_group <- cut(lwt,breaks=c(-Inf,110,Inf),right = T)
AIC(lm(bwt~lwt_group,data=da))
da$lwt_group <- cut(lwt,breaks=c(-Inf,110,130,150,Inf),right = T)
AIC(lm(bwt~lwt_group,data=da))

y<-c(95,95,106,98,102,112,105,95,
     95,94,105,97,98,112,103,92,
     89,88,97,95,97,101,97,90,
     83,84,90,90,88,94,88,80)
treat<-factor(rep(1:4,c(8,8,8,8)))
block<-factor(rep(1:8,4))
fit<-lm(y~treat+block)

#阐述其基本思想
anova(fit)

#相应的设计矩阵X，问结果应如何参数化
model.matrix(fit)

#2*2析因设计方差分析
y1<-c(1.5,3.5,1.2,4.8,2.9,3.3,3.7,2.5,4.0,1.9,3.1,2.8)
y2<-c(8.8,11.8,10.1,12.5,9.5,10.8,11.5,9.2,12.2,8.7,10.6,10.3)
y3<-c(5.7,8.5,7.5,5.5,7.9,6.8,8.7,7.0,6.2,8.2,7.3,6.5)
y4<-c(18.2,21.8,19.7,22.5,18.6,20.5,21.7,19.0,22.6,17.8,21.0,19.3)
SBP_drop<-c(y1,y2,y3,y4)
a<-factor(rep(c(0,1,0,1),c(12,12,12,12)))
b<-factor(rep(c(0,0,1,1),c(12,12,12,12)))
fit<-lm(SBP_drop~a+b+a*b)
anova(fit)

library(car)
options(contrasts = c("contr.sum", "contr.poly"))
fit<-lm(SBP_drop~a*b)
Anova(fit, type = "III")

mean(SBP_drop)
mean(SBP_drop[a==0])
mean(SBP_drop[a==1])
mean(SBP_drop[b==0])
mean(SBP_drop[b==1])

m <- aggregate(SBP_drop,by=list(a,b),FUN=mean)[,3]
m

mean <- c(mean(SBP_drop)-5.160417-3.485417,
mean(SBP_drop)+5.160417-3.485417,
mean(SBP_drop)-5.160417+3.485417,
mean(SBP_drop)+5.160417+3.485417)
SS总 <- sum((SBP_drop - mean(SBP_drop))^2)

SS交互 <- sum((m - mean)^2*12)

mean(SBP_drop[a==0])
mean(SBP_drop[a==1])
mean(SBP_drop[b==0])
mean(SBP_drop[b==1])


SS主效应a <- (mean(SBP_drop[a==0]) - mean(SBP_drop))^2*24+
(mean(SBP_drop[a==1]) - mean(SBP_drop))^2*24

SS主效应b <- (mean(SBP_drop[b==0]) - mean(SBP_drop))^2*24+
  (mean(SBP_drop[b==1]) - mean(SBP_drop))^2*24

SS误差 <- SS总 - SS主效应a - SS主效应b - SS交互

df总 <- 48-1;  df_a <- 2-1; df_b <-1; df交互<-1*1
df误差 <- df总 - df_a - df_b - df交互

F交互 <- (SS交互/df交互) / (SS误差/df误差)

anova(lm(SBP_drop ~ a+b+a*b))

data <- data.frame(SBP_drop,a,b)

library(ggplot2)
p <- ggplot(data, aes(x=a, y=SBP_drop, color=b, group=b)) +
  stat_summary(fun=mean, geom="point", size=3) +
  stat_summary(fun=mean, geom="line", linewidth=1) +
  labs(x="A药分组", y="收缩压下降值(mmHg)", color="B药分组", title="两药降压效果交互图") +
  theme_bw()
print(p)

#ggsave("/home/user/workspace/interaction_plot.png", p, width=6, height=4, dpi=150)

#协方差分析
read.csv("d://data/datasetC_glm.csv",header=T)[,-1]->da
da[1:4,]

# 不能直接讨论glu和bmi分组，因为有年龄这个混杂因素
anova(lm(glu~bmi3,data=da))

#年龄对glu有影响
anova(lm(glu~age,data=da))

#不同bmi水平组里年龄的均数不同其中普通组最年轻而肥胖组年纪大的占多数
anova(lm(age~bmi3,data=da))
aggregate(da$age,by=list(da$bmi3),FUN=mean)

#要做协方差分析，在控制年龄的情况下比较不同bmi组的glu均数
anova(lm(glu~bmi3 + age + bmi3*age,data=da))

#按bmi3的三个水平各拟一条回归直线
library(ggplot2)
p <- ggplot(data=da, aes(x=age, y=glu, color=bmi3, group=bmi3)) +geom_point()+geom_smooth(method="lm",se=F)
print(p)

#按bmi3的三个水平各拟一条回归直线的截距和斜率
da0<-da[da$bmi3=="normal",]
da1<-da[da$bmi3=="obese",]
da2<-da[da$bmi3=="overwt",]
fit0<-lm(glu~age ,data=da0)
fit1<-lm(glu~age ,data=da1)
fit2<-lm(glu~age ,data=da2)
fit0$"coefficients"
fit1$"coefficients"
fit2$"coefficients"

#相当于模型里添加了交互项
lm(glu~bmi3 + age + bmi3 * age ,data=da)

#比较不带和带有交互项的两个模型
fit <- lm(glu~bmi3 + age ,data=da)
out <- lm(glu~bmi3 + age + bmi3*age ,data=da)
anova(fit,out)

#按bmi3的三个水平各拟一条带共同斜率的回归直线

library(ggplot2)

da$bmi3 <- factor(da$bmi3, levels = c("normal", "obese", "overwt"))
m1 <- lm(glu ~ age + bmi3, data = da)

# 1) 造一张"每条线都要经过"的网格数据（三组 × 100 个年龄点）
newd <- expand.grid(
  age  = seq(min(da$age), max(da$age), length.out = 100),
  bmi3 = factor(c("normal", "obese", "overwt"), levels = levels(da$bmi3))
)

# 2) 用加性模型预测
newd$fit <- predict(m1, newdata = newd)

# 3) 散点 + 三条平行线
ggplot(da, aes(x = age, y = glu, color = bmi3)) +
  geom_point() +
  geom_line(data = newd, aes(x = age, y = fit, color = bmi3), linewidth = 1)

lm(glu~bmi3 + age,data=da)

#共同斜率等于 Σlxy / Σlxx

#共同斜率分子等于Σlxy
分子 <- (cov(da0$age,da0$glu)*98+
cov(da1$age,da1$glu)*28+
cov(da2$age,da2$glu)*111)

#共同斜率分母等于Σlxx
分母 <- var(da0$age)*98+var(da1$age)*28+var(da2$age)*111

分子 / 分母

#计算各组截距等于组均值减去"共同斜率 × 组均值自变量"

mean(da0$glu) - 0.03315861*mean(da0$age)
mean(da1$glu) - 0.03315861*mean(da1$age)
mean(da2$glu) - 0.03315861*mean(da2$age)

#比较肥胖和超重组估计和标准误，以及剩余标准差等指标的变化
summary(lm(glu~bmi3,data=da))
summary(lm(glu~bmi3+age,data=da))

new <- data.frame(bmi3 =c("normal","obese","overwt"),age=mean(da$age))
predict(lm(glu ~ bmi3 + age,data=da), new, se.fit = F)
predict(lm(glu ~ bmi3 ,data=da), new, se.fit = F)

SS总 <- var(da$glu)*239
SS分组 <- sum((aggregate(da$glu,by=list(da$bmi3),mean)[,2]-mean(da$glu))^2*table(da$bmi3))

da$e<-resid(lm(glu~bmi3,data=da))

e0<-da$e[da$bmi3=="normal"]
e1<-da$e[da$bmi3=="obese"]
e2<-da$e[da$bmi3=="overwt"]
age0<-da$age[da$bmi3=="normal"]
age1<-da$age[da$bmi3=="obese"]
age2<-da$age[da$bmi3=="overwt"]

fit0<-lm(e0~age0)
fit1<-lm(e1~age1)
fit2<-lm(e2~age2)
fit0$"coefficients"[2]
fit1$"coefficients"[2]
fit2$"coefficients"[2]

sum((age0 - mean(age0))^2)/26209.64*0.03503285+
sum((age1 - mean(age1))^2)/26209.64*0.02993767+
sum((age2 - mean(age2))^2)/26209.64*0.03244822

sum(0.03315861^2*(10524.91+3419.172+12265.56))

#回归的主效应对应的SS
anova(lm(e~age,data=da))

# 加载包
library(emmeans)

# 1. 拟合协方差分析模型（先验证平行性：group*lwt交互项P>0.05）
ancova_model <- lm(glu ~ age + bmi3, data = da)

# 2. 计算协变量校正到总均值时的各组调整均数
emm <- emmeans(ancova_model, ~ bmi3)

# 3. 用Tukey法做两两比较（3组均衡设计首选）
pairs(emm, adjust = "tukey")

# 如果需要Bonferroni校正，替换adjust参数即可
# pairs(emm, adjust = "bonferroni")
