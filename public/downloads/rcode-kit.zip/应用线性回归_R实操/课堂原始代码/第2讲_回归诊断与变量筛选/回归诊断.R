read.csv("d://data/hw.csv",header=T)[,-1]->d
attach(d)

resid(lm(glucose~tg+insulin))->e1
resid(lm(hba1c~tg+insulin))->e2
plot(e1,e2)


read.csv("d://data/datasetC.csv",header=T)[,-1]->d
attach(d)

AIC(lm(glu~1))
AIC(lm(glu~bmi))
AIC(lm(glu~age))
AIC(lm(glu~age+bmi))

start_model <- lm(glu~1)
full_model <- lm(glu~age+bmi)
step(start_model,scope = list(lower = start_model, upper = full_model), 
  direction = "forward", trace = 1)

fit<-lm(glu~age+bmi)
step(fit)

#完整AIC = n·ln(SSE/n) + 2K + n(1 + ln 2π)
#简略AIC = n·ln(SSE/n) + 2K

#仅含常数项
e<-resid(lm(glu~1))
SSE <- t(e)%*%e
AIC <- 200*log(SSE/200) + 2*2 + 200*(1 + log(2*pi))
AIC

#仅含常数项的简略AIC = n·ln(SSE/n) + 2K
200*log(SSE/200) + 2*1

#仅放入bmi
e<-resid(lm(glu~bmi))
SSE <- t(e)%*%e
AIC <- 200*log(SSE/200) + 2*3 + 200*(1 + log(2*pi))
AIC

#仅放入bmi的简略AIC = n·ln(SSE/n) + 2K
200*log(SSE/200) + 2*2

#仅放入年龄
e<-resid(lm(glu~age))
SSE <- t(e)%*%e
AIC <- 200*log(SSE/200) + 2*3 + 200*(1 + log(2*pi))
AIC

#仅放入年龄的简略AIC = n·ln(SSE/n) + 2K
200*log(SSE/200) + 2*2

#放入bmi和age
e<-resid(lm(glu~bmi+age))
SSE <- t(e)%*%e
AIC <- 200*log(SSE/200) + 2*4 + 200*(1 + log(2*pi))
AIC

#放入bmi和年龄的简略AIC = n·ln(SSE/n) + 2K
200*log(SSE/200) + 2*3

read.csv("d://data/datasetC.csv",header=T)[,-1]->d
attach(d)

start_model <- lm(glu~1)
full_model <- lm(glu~age+bmi+sleep+exercise+waist)

step(start_model,scope = list(lower = start_model, upper = full_model), direction = "forward", trace = 1)

AIC(lm(glu~age+bmi+exercise))
AIC(lm(glu~age+bmi+exercise+sleep))
AIC(lm(glu~age+bmi+exercise+sleep+waist))


-140.97+ 200*(1+log(2*pi)) + 2
-204.42+ 200*(1+log(2*pi))+ 2
-245.6+ 200*(1+log(2*pi))+ 2
-261.66+ 200*(1+log(2*pi))+ 2
-260.04+ 200*(1+log(2*pi))+ 2
-258.40+ 200*(1+log(2*pi))+ 2

add1(lm(glu ~ age + bmi + exercise, d),
     scope = ~ age + bmi + waist + sleep + exercise, test = "F")

add1(lm(glu ~ age + bmi + exercise+sleep, d),
     scope = ~ age + bmi + waist + sleep + exercise, test = "F")

#回归诊断
read.csv("d://data/datasetB.csv",header=T)[,-5]->d
attach(d)

cor(d[,-5])

fit<-lm(glu~age+bmi+waist)
fit1<-lm(glu~age+bmi)

drop1(fit,test="F")
drop1(fit1,test="F")

summary(fit)

confint(fit)
confint(fit1)



library(leaps)
fit<-regsubsets(glu~.,data=d[,-5],nbest=5)
summary(fit)
summary(fit)$adjr2

which(summary(fit)$adjr2 == max(summary(fit)$adjr2))

out<-lm(glu~age+bmi+waist+sleep+exercise)
summary(out)

library(leaps)
fit<-regsubsets(glu~.,data=d[,-1],nbest=20)
summary(fit)
summary(fit)$adjr2[16]
which(summary(fit)$adjr2 == max(summary(fit)$adjr2))

library(car)
vif(fit)
kappa(scale(d))

v <- range(eigen(cor(d))$values)
(v[2]/v[1])^0.5