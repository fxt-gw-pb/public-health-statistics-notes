x<-1:3
y<-c(2,1,3)

out<-lm(y~x)

yhat<-predict(out)
e<-y-yhat
t(e)%*%e

X<-cbind(1,x)
b<-out$"coefficients"
t(y)%*%y
t(y)%*%X%*%b
t(b)%*%t(X)%*%y
t(b)%*%t(X)%*%X%*%b
t(X)%*%X
solve(t(X)%*%X)

solve(t(X)%*%X)%*%t(X)%*%y

X%*%solve(t(X)%*%X)%*%t(X)->H

plot(x,y,xlim=c(0,4),ylim=c(0,4))
lines(x,yhat,lty=2)

