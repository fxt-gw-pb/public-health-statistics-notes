read.csv("d://data/hw.csv",header=T)[,-1]->d
attach(d)
out<-lm( glucose~tc+tg+insulin+hba1c )

library(leaps)
fit<-regsubsets(glucose~.,data=d,nbest=5)
summary(fit)
summary(fit)$adjr2

which(summary(fit)$adjr2 == max(summary(fit)$adjr2))

# tg  insulin hba1c

step(out)

# Coefficients:
(Intercept)           tg      insulin        hba1c  
     6.4996       0.4023      -0.2870       0.6632   

out1<-lm( glucose~tc+tg+insulin+hba1c )
out2<-lm( glucose~tg+insulin+hba1c )

drop1(out1,test="F") 
drop1(out2,test="F")

library(olsrr)
model <- lm(glucose ~ tc + tg + insulin + hba1c, data = d)
k <- ols_step_both_p(model, p_enter = 0.10, p_remove = 0.15)

k$model      		# 最终模型（lm 对象，直接 summary()）
k$metrics    		# 逐步过程指标：R2、调整R2、AIC、SBC、SBIC、Cp、RMSE…
k$others$beta_pval  	# 每一步入选变量的系数与 P 值
plot(k)      		# 逐步过程图

fit0 <- lm(glucose ~ 1, data = d)
add1(fit0, scope = ~ tc + tg + insulin + hba1c)

fit1 <- lm(glucose ~ hba1c, data = d)
add1(fit1, scope = ~ tc + tg + insulin + hba1c)

fit2 <- lm(glucose ~ hba1c+tc, data = d)

drop1(fit2)

add1(fit2, scope = ~ tc + tg + insulin + hba1c)

fit3 <- lm(glucose ~ hba1c+tc+insulin, data = d)

tb  <- add1(fit3, scope = ~ tc + tg + insulin + hba1c)
keep <- !is.na(tb$Df) & rownames(tb) != "<none>"   # 去掉 <none> 那一行
rss <- tb$RSS[keep]; df1 <- tb$Df[keep]
df2 <- df.residual(fit3) - df1                     
F   <- (deviance(fit3) - rss) / df1 / (rss / df2)
p   <- pf(F, df1, df2, lower.tail = FALSE)

fit4 <- lm(glucose ~ hba1c+tc+insulin+tg, data = d)

tb <- drop1(fit4)
keep <- !is.na(tb$Df) & rownames(tb) != "<none>"
rss <- tb$RSS[keep]; df1 <- tb$Df[keep]
df2 <- df.residual(fit4)                       
F   <- (rss - deviance(fit4)) / df1 / (deviance(fit4) / df2)
p   <- pf(F, df1, df2, lower.tail = FALSE)


drop1(fit3)


model_1 <- lm(glucose~hba1c ,data=d)
add1(model_1,scope= ~ tc + tg + insulin ,test="F")

