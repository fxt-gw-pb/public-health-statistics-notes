read.csv("d://data/hw.csv",header=T)[,-1]->da

attach(da)

fit <- lm( glucose ~ tc + tg + insulin + hba1c )
fit1 <- lm( glucose ~ tg + insulin + hba1c )
fit2 <- lm( glucose ~ insulin + hba1c )

summary(fit)

#删除tc

drop1(fit,test="F")

anova(fit)$"Sum Sq"[5]

anova(fit1)$"Sum Sq"[4]

偏F <- (anova(fit1)$"Sum Sq"[4] - anova(fit)$"Sum Sq"[5])/(4.038)

1-pf(偏F,1,22)

#还能删选其他自变量吗

drop1(fit1,test="F")

#以tg为例

偏F <- (anova(fit2)$"Sum Sq"[3] - anova(fit1)$"Sum Sq"[4])/(3.889)

1-pf(偏F,1,23)

#变量间相关性
cor(da)

#放入tc和tg顺序不同为什么结果不一样

anova(lm(glucose~tc+tg))
anova(lm(glucose~tg+tc))

cor(tc,tg)

library(ppcor)
pcor(da)

#glucose与tc的偏相关系数.08,P=0.7
#glucose与tg的偏相关系数.34,P=0.09

#如果要看不受顺序影响的平方和

library(car)

# 建立模型
model <- lm(glucose ~ tc + tg, data = da)

# 使用 Type II ANOVA (推荐用于没有交互作用的模型)
# Type II 检验的是：在控制其他所有主效应后，该变量的额外贡献
# 对于主效应模型，Type II 的结果与变量顺序无关
Anova(model, type = "II")

# 或者使用 Type III ANOVA (常用于有交互作用或非平衡设计)
# 注意：使用 Type III 前通常需要对因子进行对比编码设置，但对于连续变量通常直接可用
Anova(model, type = "III")

fit <- lm( glucose ~ tc + tg + insulin + hba1c )
Anova(fit, type = "II")
Anova(fit, type = "III")

zda<-scale(da)

lm(zda[,5] ~ zda[,2] + zda[,3] + zda[,4] - 1)

y<-glucose;x1<-tc;x2<-tg;x3<-insulin;x4<-hba1c
new <- data.frame(x2 = mean(x2), x3 = mean(x3), x4 = mean(x4));new
fit1 <- lm( y ~ x2 + x3 + x4 );fit1
predict(fit1, new)
predict(fit1, new,interval = "confidence")
predict(fit1, new,interval = "prediction")

pred.w.plim <- predict(lm(y ~ x), new, interval = "prediction")
pred.w.clim <- predict(lm(y ~ x), new, interval = "confidence")

library(olsrr)

# 构建模型
model <- lm(glucose ~ tc + tg + insulin + hba1c, data = da)

# 执行前进法，并显示详细步骤信息
forward_result <- ols_step_forward_p(model, p_val = 0.05, details = TRUE)

# 如果上面没有自动打印，可以手动打印结果对象
print(forward_result)

backward_result <- ols_step_backward_p(model, p_val = 0.05, details = TRUE)

ols_step_both_p(model, p_enter = 0.10, p_remove = 0.15)


